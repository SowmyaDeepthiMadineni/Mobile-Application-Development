package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity implements signup_frag.SignUpListener,Login_frag.LoginListener, post_frag.PostsListener, create_post_frag.CreateNewPostListener {

    String token = null;
    User user = null;
    SharedPreferences sharedPreferences;
    private static final String Shared_pref="name";
    private static final String TOKEN="token";
    //User USER="user";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        String tk =sharedPreferences.getString(getResources().getString(R.string.user_object),null);
        Gson gson=new Gson();

        User obj=gson.fromJson(tk,User.class);
        if (obj != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, post_frag.newInstance(TOKEN,obj))
                    .commit();

        } else {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, Login_frag.newInstance())
                    .commit();
        }
    }

    @Override
    public void loginSuccessful(String token, User user) {
        this.token = token;
        this.user = user;
        SharedPreferences.Editor editor=sharedPreferences.edit();
        Gson gson=new Gson();
        String jsonObject=gson.toJson(user);
        editor.putString(TOKEN,token);
        editor.putString(getResources().getString(R.string.user_object),jsonObject);
        editor.commit();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, post_frag.newInstance(token,user))
                .commit();
    }

    @Override
    public void createNewAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, signup_frag.newInstance())
                .commit();
    }

    @Override
    public void SignUpSuccessful(String token, User user) {
        this.token = token;
        this.user = user;
        SharedPreferences.Editor editor=sharedPreferences.edit();
        Gson gson=new Gson();
        String jsonObject=gson.toJson(user);
        editor.putString(TOKEN,token);
        editor.putString(getResources().getString(R.string.user_object),jsonObject);
        editor.commit();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, post_frag.newInstance(token,user))
                .commit();
    }


    @Override
    public void CreateNewPost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, create_post_frag.newInstance(token,user))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void Logout() {
       this.user = null;
        this.token = null;
        /*SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.clear();
        editor.commit();
        finish();*/
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, Login_frag.newInstance())
                .commit();
    }

    @Override
    public void createPostSuccessful() {

        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void CreatePostCancel() {

        getSupportFragmentManager().popBackStack();
    }
}