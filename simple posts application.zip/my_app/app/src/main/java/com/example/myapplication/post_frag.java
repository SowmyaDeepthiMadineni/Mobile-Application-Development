package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link post_frag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class post_frag extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String TOKEN = "param1";
    private static final String USER = "param2";

    String token;
    User user;
    OkHttpClient client = new OkHttpClient();
    Gson gson = new Gson();
    int curr_page_number;

    public post_frag() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static post_frag newInstance(String token, User user) {
        post_frag fragment = new post_frag();
        Bundle args = new Bundle();
        args.putString(TOKEN, token);
        args.putSerializable(USER, user);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString(TOKEN);
            user = (User) getArguments().getSerializable(USER);
        }
    }

    RecyclerView rvShowPageNumber,rvShowPosts;
    TextView tvShowingPageNumber;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_post_frag, container, false);
        RecyclerView rvPosts = view.findViewById(R.id.rvPosts_post);
        rvPosts.setLayoutManager(new LinearLayoutManager(getContext()));

        TextView tvWelcome = view.findViewById(R.id.tvWelome_post);
        tvWelcome.setText(getString(R.string.Welcome_Text)+" "+user.userName);

        tvShowingPageNumber = view.findViewById(R.id.tv_showingPage_post);
        rvShowPageNumber = view.findViewById(R.id.rvPageNumbers_post);
        rvShowPageNumber.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL,false));
        rvShowPosts = view.findViewById(R.id.rvPosts_post);
        rvShowPosts.setLayoutManager(new LinearLayoutManager(getContext()));

        curr_page_number = 1;
        GetPagePosts(1);

        view.findViewById(R.id.btnCreatePost_post).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postsListener.CreateNewPost();
            }
        });

        view.findViewById(R.id.btnLogout_post).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postsListener.Logout();
            }
        });

        return view;
    }

    PostsListener postsListener;
    interface PostsListener{
        void CreateNewPost();
        void Logout();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof PostsListener) {
            postsListener = (PostsListener) context;
        } else {
            throw new RuntimeException(context.toString() + "must implement IListener");
        }
    }

    class RVAdapterForPost extends RecyclerView.Adapter<RVAdapterForPost.ViewHolder> {

        List<Post> posts = new ArrayList<>();

        public RVAdapterForPost(List<Post> posts) {
            this.posts = posts;
        }

        @NonNull
        @Override
        public RVAdapterForPost.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_view,parent,false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RVAdapterForPost.ViewHolder holder, int position) {
            Post post = posts.get(position);
            holder.tvPostValue.setText(post.post_text);
            holder.tvPostAuthor.setText(post.created_by_name);
            holder.tvPostTime.setText(post.created_at);
            if(user.id==Integer.valueOf(post.created_by_uid)){
                holder.ivDelete.setVisibility(View.VISIBLE);
                holder.ivDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DeleteThePost(post.post_id);
                    }
                });
            }else{
                holder.ivDelete.setVisibility(View.GONE);
            }
        }


        private void DeleteThePost(String postId) {
            RequestBody formBody = new FormBody.Builder()
                    .add("post_id", postId)
                    .build();

            Request request = new Request.Builder()
                    .url("https://www.theappsdr.com/posts/delete")
                    .addHeader("Authorization", "BEARER " + token)
                    .post(formBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override public void onResponse(Call call, Response response){
                    try (ResponseBody responseBody = response.body()) {
                        String result = responseBody.string();
                        JSONObject root = new JSONObject(result);
                        String tost_msg;
                        if (!response.isSuccessful()){
                            tost_msg = root.getString("message");
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),tost_msg , Toast.LENGTH_SHORT).show();
                                }
                            });

                        }else{
                            tost_msg = root.getString("message");
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),tost_msg , Toast.LENGTH_SHORT).show();
                                }
                            });
                            GetPagePosts(curr_page_number);
                        }

                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return posts.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPostValue,tvPostAuthor,tvPostTime;
            ImageView ivDelete;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvPostValue = itemView.findViewById(R.id.tvPostText_postView);
                tvPostAuthor = itemView.findViewById(R.id.tvPostAuthor_postView);
                tvPostTime = itemView.findViewById(R.id.tvPostTime_postView);
                ivDelete = itemView.findViewById(R.id.ivDelete_postView);
            }
        }
    }

    class RVAdapterForPage extends RecyclerView.Adapter<RVAdapterForPage.ViewHolder>{


        int pages;
        public RVAdapterForPage(int pages) {
            this.pages = pages;
        }

        @NonNull
        @Override
        public RVAdapterForPage.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.page_number_view,parent,false);
            return new RVAdapterForPage.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RVAdapterForPage.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
            holder.tvPageNumber.setText((position+1)+"");
            holder.cardContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    curr_page_number = position+1;
                    GetPagePosts(curr_page_number);
                }
            });

        }

        @Override
        public int getItemCount() {
            return pages;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPageNumber;
            CardView cardContainer;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                cardContainer = itemView.findViewById(R.id.cardContainer_pageNumberview);
                tvPageNumber = itemView.findViewById(R.id.tvPageNumber_pageNumberView);
            }
        }
    }

    void GetPagePosts(int position) {
        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts?page="+position)
                .addHeader("Authorization", "BEARER " + token)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response){
                try (ResponseBody responseBody = response.body()) {
                    String result = responseBody.string();
                    JSONObject root = new JSONObject(result);
                    String tost_msg;
                    if (!response.isSuccessful()){
                        String finalTost_msg = root.getString("message");;
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getContext(), finalTost_msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                    }else{
                        tost_msg = root.getString("status");
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getContext(), tost_msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        List<Post> posts = new ArrayList<>();
                        JSONArray arr = root.getJSONArray("posts");
                        String tmp;
                        for(int i=0;i<arr.length();i++){
                            tmp = arr.get(i).toString();
                            posts.add(gson.fromJson(tmp,Post.class));
                        }
                        int pages = root.getInt("totalCount")/10;
                        String pageNumber = root.getString("page");
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                rvShowPosts.setAdapter(new RVAdapterForPost(posts));
                                rvShowPageNumber.setAdapter(new RVAdapterForPage(pages));
                                tvShowingPageNumber.setText("Showing page "+pageNumber+" of "+pages);
                            }
                        });


                    }

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


}