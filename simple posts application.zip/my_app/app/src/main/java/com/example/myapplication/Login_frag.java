package com.example.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Login_frag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Login_frag extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Login_frag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.

     * @return A new instance of fragment Login_fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Login_frag newInstance() {
        Login_frag fragment = new Login_frag();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    Gson gson = new Gson();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login_fragment, container, false);

        EditText etEmail,etPassword;
        etEmail = view.findViewById(R.id.etUserName_login);
        etPassword = view.findViewById(R.id.etPassword_login);



        view.findViewById(R.id.tvCreateNewAccount_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginListener.createNewAccount();
            }
        });

        OkHttpClient client = new OkHttpClient();

        view.findViewById(R.id.btnLogin_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etEmail.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_Email));
                    return;
                }
                if(etPassword.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_Password));
                    return;
                }
                RequestBody formBody = new FormBody.Builder()
                        .add("email", etEmail.getText().toString())
                        .add("password", etPassword.getText().toString())
                        .build();
                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/posts/login")
                        .post(formBody)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override public void onResponse(Call call, Response response){
                        try (ResponseBody responseBody = response.body()) {
                            String result = responseBody.string();
                            JSONObject root = new JSONObject(result);

                            if (!response.isSuccessful()){
                                String tost_msg = root.getString("message");
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(),tost_msg , Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }else{
                                String token = root.getString("token");
                                String userName = root.getString("user_fullname");
                                int id = root.getInt("user_id");
                                User user =  new User(userName,id);
                                loginListener.loginSuccessful(token,user);
                            }

                        } catch (IOException | JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });

            }
        });

        return view;
    }

    void showAlertDialogBox(String msg){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(msg)
                .setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // FIRE ZE MISSILES!
                    }
                });
        builder.create().show();
    }



    LoginListener loginListener;
    interface LoginListener {
        void loginSuccessful(String token,User user);
        void createNewAccount();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginListener) {
            loginListener = (LoginListener) context;
        } else {
            throw new RuntimeException(context.toString() + "must implement IListener");
        }
    }
}