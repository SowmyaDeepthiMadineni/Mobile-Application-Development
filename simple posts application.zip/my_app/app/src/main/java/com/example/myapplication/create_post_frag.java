package com.example.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link create_post_frag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class create_post_frag extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String TOKEN = "param1";
    private static final String USER = "param2";

    // TODO: Rename and change types of parameters
    String token;
    User user;

    public create_post_frag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment create_post_frag.
     */
    // TODO: Rename and change types and number of parameters
    public static create_post_frag newInstance(String token, User user) {
        create_post_frag fragment = new create_post_frag();
        Bundle args = new Bundle();
        args.putString(TOKEN, token);
        args.putSerializable(USER, user);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString(TOKEN);
            user = (User) getArguments().getSerializable(USER);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_create_post_frag, container, false);

        TextView tvCancel = view.findViewById(R.id.tvCancel_newPost);
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                createNewPostListener.CreatePostCancel();
            }
        });

        EditText etEnterPost = view.findViewById(R.id.etEnterPost_newPost);

        OkHttpClient client = new OkHttpClient();

        view.findViewById(R.id.btnSubmit_newPost).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etEnterPost.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_Post));
                    return;
                }

                RequestBody formBody = new FormBody.Builder()
                        .add("post_text", etEnterPost.getText().toString())
                        .build();

                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/posts/create")
                        .addHeader("Authorization", "BEARER " + token)
                        .post(formBody)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override public void onResponse(Call call, Response response){
                        try (ResponseBody responseBody = response.body()) {
                            String result = responseBody.string();
                            JSONObject root = new JSONObject(result);
                            String tost_msg;
                            if (!response.isSuccessful()){
                                tost_msg = root.getString("message");
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(), tost_msg, Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }else{
                                tost_msg = root.getString("message");
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(), tost_msg, Toast.LENGTH_SHORT).show();
                                    }
                                });

                                createNewPostListener.createPostSuccessful();
                            }

                        } catch (IOException | JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });

            }
        });

        return view;
    }

    void showAlertDialogBox(String msg){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(msg)
                .setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // FIRE ZE MISSILES!
                    }
                });
        builder.create().show();
    }

    CreateNewPostListener createNewPostListener;
    interface CreateNewPostListener{
        void createPostSuccessful();
        void CreatePostCancel();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof CreateNewPostListener) {
            createNewPostListener = (CreateNewPostListener) context;
        } else {
            throw new RuntimeException(context.toString() + "must implement IListener");
        }
    }
}