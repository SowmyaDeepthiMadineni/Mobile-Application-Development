package com.example.myapplication;

import java.io.Serializable;

public class User implements Serializable {
    String userName;
    int id;

    public User(String userName, int id) {
        this.userName = userName;
        this.id = id;
    }
}
