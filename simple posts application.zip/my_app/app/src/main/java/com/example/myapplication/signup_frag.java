package com.example.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link signup_frag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class signup_frag extends Fragment {


    public signup_frag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment signup_frag.
     */
    // TODO: Rename and change types and number of parameters
    public static signup_frag newInstance() {
        signup_frag fragment = new signup_frag();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signup_frag, container, false);

        EditText etEmail,etPassword,etUserName;
        etUserName = view.findViewById(R.id.etName_signup);
        etEmail = view.findViewById(R.id.etEmail_signup);
        etPassword = view.findViewById(R.id.etPassword_signup);
        TextView cancel=view.findViewById(R.id.tvCancel_signup);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUpListener.Logout();
            }
        });

        OkHttpClient client = new OkHttpClient();


        view.findViewById(R.id.btnSignup_signup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etUserName.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_UserName));
                    return;
                }
                if(etEmail.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_Email));
                    return;
                }
                if(etPassword.getText().toString().isEmpty()){
                    showAlertDialogBox(getString(R.string.Alert_Provide_Password));
                    return;
                }

                RequestBody formBody = new FormBody.Builder()
                        .add("name", etUserName.getText().toString())
                        .add("email", etEmail.getText().toString())
                        .add("password", etPassword.getText().toString())
                        .build();

                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/posts/signup")
                        .post(formBody)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override public void onResponse(Call call, Response response){
                        try (ResponseBody responseBody = response.body()) {
                            String result = responseBody.string();
                            JSONObject root = new JSONObject(result);
                            if (!response.isSuccessful()){
                                String tost_msg = root.getString("message");
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(), tost_msg, Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }else{
                                String token = root.getString("token");
                                String userName = root.getString("user_fullname");
                                int id = root.getInt("user_id");
                                User user =  new User(userName,id);
                                signUpListener.SignUpSuccessful(token,user);
                            }

                        } catch (IOException | JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });

            }
        });


        return view;
    }

    void showAlertDialogBox(String msg){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(msg)
                .setPositiveButton(R.string.Ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // FIRE ZE MISSILES!
                    }
                });
        builder.create().show();
    }

    SignUpListener signUpListener;
    interface SignUpListener {
        void SignUpSuccessful(String token,User user);

        void Logout();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof SignUpListener) {
            signUpListener = (SignUpListener) context;
        } else {
            throw new RuntimeException(context.toString() + "must implement IListener");
        }
    }

}