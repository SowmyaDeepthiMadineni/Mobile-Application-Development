//InClass06
//Sowmya Deepthi Madineni
//MainActivity.java

package com.example.inclass_06;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    ListView averageNumbers;
    SeekBar seekBar;
    TextView SBValue;
    TextView averageValue;
    TextView progressvalue,textViewValue;
    ProgressBar progressBar;
    Button Generate;
    ExecutorService threadpool;
    Handler handler;
    int seekBarProgress;
    double randomsum=0,randomaverage=0;
     EditText editTextNumber;
    ArrayList<Double> average=new ArrayList<>();
    ArrayAdapter<Double> numberslistAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        threadpool= Executors.newFixedThreadPool(2);
        averageValue= findViewById(R.id.textViewAverage);
        averageValue.setVisibility(View.INVISIBLE);
        seekBar=findViewById(R.id.seekBar);
        Generate=findViewById(R.id.buttonGenerate);
        SBValue=findViewById(R.id.SeekBarValue);
        progressBar=findViewById(R.id.progressBar);
        averageNumbers=findViewById(R.id.ListView);
        progressvalue=findViewById(R.id.ProgressCount);
        textViewValue=findViewById((R.id.textViewValue));
        numberslistAdapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,android.R.id.text1,average);
        averageNumbers.setAdapter(numberslistAdapter);
        progressBar.setVisibility(View.INVISIBLE);
        textViewValue.setVisibility(View.INVISIBLE);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int Progress, boolean b) {
                seekBarProgress=Progress;
                if(seekBarProgress==0){
                    SBValue.setText("");
                }
                else{
                    SBValue.setText(String.valueOf(Progress));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        handler=new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                int count= message.what;
                double avg= (double) message.obj;
                progressBar.setVisibility(View.VISIBLE);
                averageValue.setVisibility(View.VISIBLE);
                textViewValue.setVisibility(View.VISIBLE);
                progressBar.setMax(seekBarProgress);
                progressBar.setProgress((count + 1));
                String finalresult = new Double(avg).toString();
                textViewValue.setText(finalresult);
                progressvalue.setText((count+1) + "/" + seekBarProgress);
                numberslistAdapter.notifyDataSetChanged();
                return false;
            }
        });

        Generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                threadpool.execute(new Runnable() {
                    @Override
                    public void run() {
                        for(int i=0;i<seekBarProgress;i++) {
                            average.add(HeavyWork.getNumber());
                            randomsum += average.get(i);
                            randomaverage=randomsum/(i+1);
                            Message message=new Message();
                            message.what=i;
                            message.obj=randomaverage;
                            handler.sendMessage(message);


                        }
                    }
                });

            }
        });
        }
    }
