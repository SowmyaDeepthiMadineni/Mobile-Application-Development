//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CitiesFragmentAdapter extends RecyclerView.Adapter<CitiesFragmentAdapter.CitiesViewHolder> {
    ArrayList<Data.City> cities;
    AdapterInterface cities_fragment;
    final String TAG="demo";
    public CitiesFragmentAdapter(ArrayList<Data.City> cities, AdapterInterface cities_fragment) {
        this.cities=cities;
        this.cities_fragment=cities_fragment;
    }


    @NonNull
    @Override
    public CitiesFragmentAdapter.CitiesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1,parent,false);
        CitiesViewHolder citiesview=new CitiesViewHolder(view,cities_fragment);
        return citiesview;
    }

    @Override
    public void onBindViewHolder(@NonNull CitiesFragmentAdapter.CitiesViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Data.City Nameofcity = cities.get(position);
        holder.CityandCountry.setText(Nameofcity.getCity() + ", " + Nameofcity.getCountry());
        holder.cityindex = position;
        holder.nameofcity = Nameofcity;

    }

    @Override
    public int getItemCount() {
        return cities.size();
    }

    public class CitiesViewHolder extends RecyclerView.ViewHolder {
        TextView CityandCountry;
        Data.City nameofcity;
        int cityindex;
        AdapterInterface cities_fragment;
        public CitiesViewHolder(@NonNull View itemView, AdapterInterface cities_fragment) {
            super(itemView);
            CityandCountry=itemView.findViewById(android.R.id.text1);
            this.cities_fragment=cities_fragment;
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d(TAG,"name of the city"+nameofcity );
                    cities_fragment.passDataToCityFragment(nameofcity);
                }
            });
        }
    }
    interface AdapterInterface{
        void passDataToCityFragment(Data.City cityName);
    }
}
