//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

public class DetailsofCurrentWeather {
    String maxPredictedTemp,minPredictedTemp,TempofDay,humidity,pressurelevel;

    @Override
    public String toString() {
        return "DetailsofCurrentWeather{" +
                "maxPredictedTemp='" + maxPredictedTemp + '\'' +
                ", minPredictedTemp='" + minPredictedTemp + '\'' +
                ", TempofDay='" + TempofDay + '\'' +
                ", humidity='" + humidity + '\'' +
                ", pressurelevel='" + pressurelevel + '\'' +
                '}';
    }

    public String getMaxPredictedTemp() {
        return maxPredictedTemp;
    }

    public void setMaxPredictedTemp(String maxPredictedTemp) {
        this.maxPredictedTemp = maxPredictedTemp;
    }

    public String getMinPredictedTemp() {
        return minPredictedTemp;
    }

    public void setMinPredictedTemp(String minPredictedTemp) {
        this.minPredictedTemp = minPredictedTemp;
    }

    public String getTempofDay() {
        return TempofDay;
    }

    public void setTempofDay(String tempofDay) {
        TempofDay = tempofDay;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getPressurelevel() {
        return pressurelevel;
    }

    public void setPressurelevel(String pressurelevel) {
        this.pressurelevel = pressurelevel;
    }
}
