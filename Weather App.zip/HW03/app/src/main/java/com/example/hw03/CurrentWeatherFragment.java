//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CurrentWeatherFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CurrentWeatherFragment extends Fragment {
    private static final String apikey = "key";
    private static final String CITY = "CITY";
    Data.City cityName;
    String account_key;
    TextView city;
    TextView temperature;
    TextView MaxTemp;
    TextView MinTemp;
    TextView description;
    TextView humidity;
    TextView windSpeed;
    TextView windDegree;
    TextView Cloudiness;
    ImageView TempIcon;
    Button forecast;
    weatherInterface weatherinterface;

    public CurrentWeatherFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static CurrentWeatherFragment newInstance(Data.City cityValue, String cityIndex) {
        CurrentWeatherFragment fragment = new CurrentWeatherFragment();
        Bundle args = new Bundle();
        args.putSerializable(CITY, cityValue);
        args.putString(apikey, cityIndex);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            cityName = (Data.City) getArguments().getSerializable(CITY);
            account_key = getArguments().getString(apikey);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_current_weather, container, false);
        city = view.findViewById(R.id.CityName);
        temperature = view.findViewById(R.id.TemperatureValue);
        MaxTemp = view.findViewById(R.id.MaxTempValue);
        MinTemp = view.findViewById(R.id.MinTempValue);
        description = view.findViewById(R.id.DescriptionValue);
        humidity = view.findViewById(R.id.HumidityValue);
        windSpeed = view.findViewById(R.id.WindspeedValue);
        windDegree = view.findViewById(R.id.WinddegreeValue);
        Cloudiness = view.findViewById(R.id.CloudinessValue);
        TempIcon = view.findViewById(R.id.WeatherIcon);
        forecast=view.findViewById(R.id.buttonForecast);
        forecast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                weatherinterface.ForecastedWeather(cityName);
            }
        });
        new getCurrentWeatherDetails().execute(cityName.getCity(), cityName.getCountry(), account_key);
        return view;
    }
    class getCurrentWeatherDetails extends AsyncTask<String,String,WeatherForecastInfo>{
        final OkHttpClient client = new OkHttpClient();
        String receivedCityName, receivedCountryName;
        @Override
        protected WeatherForecastInfo doInBackground(String... strings) {
            receivedCityName = strings[0];
            receivedCountryName = strings[1];
            HttpUrl url = HttpUrl.parse("https://api.openweathermap.org/data/2.5/weather").newBuilder()
                    .addQueryParameter("q", strings[0])
                    .addQueryParameter("appid", strings[2])
                    .addQueryParameter("units", "imperial")
                    .build();
            Request req = new Request.Builder()
                    .url(url)
                    .build();
            WeatherForecastInfo forecastdetails = new WeatherForecastInfo();
            try {
                Response response = client.newCall(req).execute();
                if (response.isSuccessful()){
                    TypesofWeather weather = new TypesofWeather();
                    ArrayList<TypesofWeather> weathertype = new ArrayList<>();
                    WindyWeather windCondition = new WindyWeather();
                    CloudyWeather cloudCondition = new CloudyWeather();
                    DetailsofCurrentWeather currentWeatherdetails = new DetailsofCurrentWeather();
                    JSONObject json = new JSONObject(response.body().string());
                    JSONArray weatherdetails = json.getJSONArray("weather");
                    JSONObject windObject = json.getJSONObject("wind");
                    JSONObject cloudObject = json.getJSONObject("clouds");
                    JSONObject weatherObject = weatherdetails.getJSONObject(0);
                    JSONObject currentTempObject = json.getJSONObject("main");
                    weather.setDesc(weatherObject.getString("description"));
                    weather.setClimaticConditionIcon(weatherObject.getString("icon"));
                    weathertype.add(weather);
                    currentWeatherdetails.setTempofDay(currentTempObject.getString("temp"));
                    currentWeatherdetails.setMaxPredictedTemp(currentTempObject.getString("temp_max"));
                    currentWeatherdetails.setMinPredictedTemp(currentTempObject.getString("temp_min"));
                    currentWeatherdetails.setHumidity(currentTempObject.getString("humidity"));
                    currentWeatherdetails.setPressurelevel(currentTempObject.getString("pressure"));
                    windCondition.setWindDegree(windObject.getString("deg"));
                    windCondition.setWindSpeed(windObject.getString("speed"));
                    cloudCondition.setCloudyweather(cloudObject.getString("all"));
                    forecastdetails.setCurrentWeather(currentWeatherdetails);
                    forecastdetails.setWeatherTypes(weathertype);
                    forecastdetails.setWindCondition(windCondition);
                    forecastdetails.setCloudCondition(cloudCondition);
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return forecastdetails;
        }
        protected void onPostExecute(WeatherForecastInfo totalTemperatureData) {
            if (totalTemperatureData != null){
                String icon = totalTemperatureData.getWeatherTypes().get(0).getClimaticConditionIcon();
                String iconUrl = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
                city.setText(receivedCityName + ", " + receivedCountryName);
               temperature.setText(totalTemperatureData.currentWeather.getTempofDay() + " F");
                MaxTemp.setText(totalTemperatureData.currentWeather.getMaxPredictedTemp() + " F");
                MinTemp.setText(totalTemperatureData.currentWeather.getMinPredictedTemp() + " F");
                description.setText(totalTemperatureData.weatherTypes.get(0).description);
                humidity.setText(totalTemperatureData.currentWeather.getHumidity() + "%");
                windSpeed.setText(totalTemperatureData.windCondition.getWindSpeed() + " miles/hr");
                windDegree.setText(totalTemperatureData.windCondition.getWindDegree() + " degrees");
                Cloudiness.setText(totalTemperatureData.cloudCondition.getCloudyweather() + " %");
                Picasso.get()
                      .load(iconUrl)
                        .into(TempIcon);
            }
            else {
                Toast.makeText(getContext(), "forecast info is not having ay details", Toast.LENGTH_SHORT).show();
            }
        }

        }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof weatherInterface){
            weatherinterface = (weatherInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString());
        }
    }
    public interface weatherInterface{
        void ForecastedWeather(Data.City city);
    }
}