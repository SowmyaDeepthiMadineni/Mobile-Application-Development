//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

public class CloudyWeather {
    String cloudyweather;

    @Override
    public String toString() {
        return "CloudyWeather{" +
                "cloudyweather='" + cloudyweather + '\'' +
                '}';
    }

    public String getCloudyweather() {

        return cloudyweather;
    }

    public void setCloudyweather(String cloudyweather) {

        this.cloudyweather = cloudyweather;
    }
}
