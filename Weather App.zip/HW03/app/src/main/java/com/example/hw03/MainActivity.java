//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity implements Cities_Fragment.cityfragmentInterface,CurrentWeatherFragment.weatherInterface{
    public static final String apikey= "a805f5c7e2c69a02507fa4261dfdfcc3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootview, new Cities_Fragment())
                .commit();
    }

    public void TodaysWeather(Data.City city) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootview, CurrentWeatherFragment.newInstance(city, apikey))
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void ForecastedWeather(Data.City city) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootview, WeatherForeCastFragment.newInstance(city, apikey))
                .addToBackStack(null)
                .commit();

    }
}