//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

import java.util.ArrayList;

public class WeatherForecastInfo {
    String dates;
    ArrayList<TypesofWeather> weatherTypes;
    CloudyWeather cloudCondition;
    WindyWeather windCondition;
    DetailsofCurrentWeather currentWeather;

    @Override
    public String toString() {
        return "WeatherForecastInfo{" +
                "dates='" + dates + '\'' +
                ", weatherTypes=" + weatherTypes +
                ", cloudCondition=" + cloudCondition +
                ", windCondition=" + windCondition +
                ", currentWeather=" + currentWeather +
                '}';
    }

    public String getDates() {

        return dates;
    }

    public void setDates(String dates) {

        this.dates = dates;
    }

    public ArrayList<com.example.hw03.TypesofWeather> getWeatherTypes() {

        return weatherTypes;
    }

    public void setWeatherTypes(ArrayList<com.example.hw03.TypesofWeather> weatherTypes) {
        this.weatherTypes = weatherTypes;
    }

    public CloudyWeather getCloudCondition() {

        return cloudCondition;
    }

    public void setCloudCondition(CloudyWeather cloudCondition) {
        this.cloudCondition = cloudCondition;
    }

    public WindyWeather getWindCondition() {

        return windCondition;
    }

    public void setWindCondition(WindyWeather windCondition) {

        this.windCondition = windCondition;
    }

    public DetailsofCurrentWeather getCurrentWeather() {
        return currentWeather;

    }

    public void setCurrentWeather(DetailsofCurrentWeather currentWeather) {
        this.currentWeather = currentWeather;
    }


}
