//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;




import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import java.util.ArrayList;


import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link WeatherForeCastFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WeatherForeCastFragment extends Fragment {

    private static final String CITY = "CITY";
    private static final String KEY = "API_KEY";
    TextView forecastedcityName;
    RecyclerView forecastdetails;
    LinearLayoutManager forecastlayout;
    WeatherForeCastAdapter forecastadapter;
    Data.City cityname;
    String apikey;


    public WeatherForeCastFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static WeatherForeCastFragment newInstance(Data.City cityname, String keyvalue) {
        WeatherForeCastFragment fragment = new WeatherForeCastFragment();
        Bundle args = new Bundle();
        args.putSerializable(CITY, cityname);
        args.putString(KEY, keyvalue);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            cityname = (Data.City) getArguments().getSerializable(CITY);
            apikey = getArguments().getString(KEY);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather_fore_cast, container, false);
        forecastedcityName = view.findViewById(R.id.ForecastedCityname);
        forecastdetails = view.findViewById(R.id.ForecastedDetails);
        forecastdetails.setHasFixedSize(true);
         forecastlayout = new LinearLayoutManager(getContext());
         forecastdetails.setLayoutManager(forecastlayout);
        new getWeatherforecastData().execute(cityname.getCity(), cityname.getCountry(), apikey);
        return view;
    }

    class getWeatherforecastData extends AsyncTask<String, Integer, ArrayList<WeatherForecastInfo>> {

        final OkHttpClient client = new OkHttpClient();
        String cityName, countryName;

        @Override
        protected ArrayList<WeatherForecastInfo> doInBackground(String... strings) {

            cityName = strings[0];
            countryName = strings[1];

            HttpUrl url = HttpUrl.parse("https://api.openweathermap.org/data/2.5/forecast").newBuilder()
                    .addQueryParameter("q", strings[0])
                    .addQueryParameter("appid", strings[2])
                    .addQueryParameter("units", "imperial")
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            ArrayList<WeatherForecastInfo> weatherforecastinfo = new ArrayList<>();

            try {
                Response response = client.newCall(request).execute();

                if (response.isSuccessful()){
                    JSONObject obj = new JSONObject(response.body().string());
                    JSONArray fivedaysforecast = obj.getJSONArray("list");

                    for (int i = 0; i < fivedaysforecast.length(); i++){

                        TypesofWeather weathertype = new TypesofWeather();
                        ArrayList<TypesofWeather> weatherList = new ArrayList<>();
                        WindyWeather wind = new WindyWeather();
                        DetailsofCurrentWeather temperatureInformation = new DetailsofCurrentWeather();
                        CloudyWeather cloud = new CloudyWeather();
                        WeatherForecastInfo forecastinfo = new WeatherForecastInfo();



                        JSONObject jsonObject = fivedaysforecast.getJSONObject(i);
                        JSONArray weatherArray = jsonObject.getJSONArray("weather");
                        JSONObject weatherJSONObject = weatherArray.getJSONObject(0);
                        JSONObject mainTempJSONObject = jsonObject.getJSONObject("main");
                        JSONObject windJSONObject = jsonObject.getJSONObject("wind");
                        JSONObject cloudJSONObject = jsonObject.getJSONObject("clouds");

                        weathertype.setDesc(weatherJSONObject.getString("description"));
                        weathertype.setClimaticConditionIcon(weatherJSONObject.getString("icon"));
                        weatherList.add(weathertype);

                        temperatureInformation.setTempofDay(mainTempJSONObject.getString("temp"));
                        temperatureInformation.setMaxPredictedTemp(mainTempJSONObject.getString("temp_max"));
                        temperatureInformation.setMinPredictedTemp(mainTempJSONObject.getString("temp_min"));
                        temperatureInformation.setHumidity(mainTempJSONObject.getString("humidity"));
                        temperatureInformation.setPressurelevel(mainTempJSONObject.getString("pressure"));

                        wind.setWindDegree(windJSONObject.getString("deg"));
                        wind.setWindSpeed(windJSONObject.getString("speed"));

                        cloud.setCloudyweather(cloudJSONObject.getString("all"));

                        forecastinfo.setCurrentWeather(temperatureInformation);
                        forecastinfo.setWeatherTypes(weatherList);
                        forecastinfo.setWindCondition(wind);
                        forecastinfo.setCloudCondition(cloud);
                        forecastinfo.setDates(jsonObject.getString("dt_txt"));

                        weatherforecastinfo.add(i, forecastinfo);


                    }

                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return weatherforecastinfo;
        }


        @Override
        protected void onPostExecute(ArrayList<WeatherForecastInfo> weatherforecastinfo) {

            if (weatherforecastinfo.size() != 0){
                forecastedcityName.setText(cityName + ", " + countryName);
                forecastadapter = new WeatherForeCastAdapter(weatherforecastinfo);
                forecastdetails.setAdapter(forecastadapter);
            }
            else {
                Toast.makeText(getContext(), "the forecast info doesnot contain any value", Toast.LENGTH_SHORT).show();
            }
        }
    }
}