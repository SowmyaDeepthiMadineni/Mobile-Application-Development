//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

public class WindyWeather {
    String windSpeed,windDegree;

    @Override
    public String toString() {
        return "WindyWeather{" +
                "windSpeed='" + windSpeed + '\'' +
                ", windDegree='" + windDegree + '\'' +
                '}';
    }

    public String getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getWindDegree() {
        return windDegree;
    }

    public void setWindDegree(String windDegree) {
        this.windDegree = windDegree;
    }
}
