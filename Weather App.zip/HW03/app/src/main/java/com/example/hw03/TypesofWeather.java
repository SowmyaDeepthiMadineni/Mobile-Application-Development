//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati

package com.example.hw03;

public class TypesofWeather {
    String description;
    String climaticConditionIcon;

    @Override
    public String toString() {
        return "TypesofWeather{" +
                "desc='" + description + '\'' +
                ", climaticConditionIcon='" + climaticConditionIcon + '\'' +
                '}';
    }

    public String getDesc() {
        return description;
    }

    public void setDesc(String desc) {
        this.description = desc;
    }

    public String getClimaticConditionIcon() {
        return climaticConditionIcon;
    }

    public void setClimaticConditionIcon(String climaticConditionIcon) {
        this.climaticConditionIcon = climaticConditionIcon;
    }

}
