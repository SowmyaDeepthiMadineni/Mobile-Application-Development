//Group1-11
//Sowmya Deepthi Madineni
//Deep Prajapati


package com.example.hw03;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class WeatherForeCastAdapter extends RecyclerView.Adapter<WeatherForeCastAdapter.forecastValue>{
    ArrayList<WeatherForecastInfo> forecastInfo;
    public WeatherForeCastAdapter(ArrayList<WeatherForecastInfo> weatherinfo) {
        this.forecastInfo = weatherinfo;
    }
    @NonNull
    @Override
    public forecastValue onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forecastadapter, parent, false);
        forecastValue viewHolder = new forecastValue(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull forecastValue holder, int position) {

        WeatherForecastInfo details = forecastInfo.get(position);
        String icon = details.getWeatherTypes().get(0).getClimaticConditionIcon();
        String url = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
        holder.date.setText(details.getDates());
        holder.minTemp.setText("Min: " + details.getCurrentWeather().getMinPredictedTemp() + " F");
        holder.maxTemp.setText("Max: " + details.getCurrentWeather().getMaxPredictedTemp() + " F");
        holder.Temperature.setText(details.getCurrentWeather().getTempofDay() + " F");
        holder.description.setText(details.getWeatherTypes().get(0).getDesc());
        holder.humidityValue.setText(details.getCurrentWeather().getHumidity()+ "%");
        Picasso.get()
                .load(url)
                .into(holder.icon);
    }
    @Override
    public int getItemCount() {

        return forecastInfo.size();
    }
    public static class forecastValue extends RecyclerView.ViewHolder{
        ImageView icon;
        TextView date;
        TextView Temperature;
        TextView maxTemp;
        TextView minTemp;
        TextView humidityValue;
        TextView description;

        public forecastValue(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.ForecastWeatherIcon);
            date = itemView.findViewById(R.id.foreCastDate);
            Temperature = itemView.findViewById(R.id.ForecastTemp);
            maxTemp = itemView.findViewById(R.id.MaxforecastTemp);
            minTemp = itemView.findViewById(R.id.MinforecastTemp);
            humidityValue = itemView.findViewById(R.id.ForecastHumidityValue);
            description = itemView.findViewById(R.id.ForecastDesc);

        }
    }
}
