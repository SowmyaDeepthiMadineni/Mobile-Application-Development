package com.example.inclass08;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;

public class Account implements Serializable {
     String name, email,uid;
    public Account(String name, String email,String uid) {
        this.name = name;
        this.email = email;
        this.uid = uid;
    }

    public Account() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String  getUid() {
        return uid;
    }

    public void setUid(String  uid) {
        this.uid = uid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return uid == account.uid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(uid);
    }

    @Override
    public String toString() {
        return "Account{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", uid=" + uid +
                '}';
    }
}
