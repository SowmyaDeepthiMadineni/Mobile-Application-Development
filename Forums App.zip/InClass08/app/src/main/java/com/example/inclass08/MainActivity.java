package com.example.inclass08;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginInterface, CreateNewAccountFragment.CreateAccountInterface, ForumsFragment.ForumsInterface, NewForumFragment.NewForumInterface {

    static long USER_ID_COUNTER = 1;
    static long FORUM_ID_COUNTER = 1;
    Account account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.containerView, new LoginFragment())
                .commit();

    }

    @Override
    public void loginUser() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumsFragment())
                .commit();
    }

    @Override
    public void goToCreateNewAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new CreateNewAccountFragment())
                .commit();
    }

    @Override
    public void createNewUser(String name, String email,String uid) {
        account = new Account(name, email,uid);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, ForumsFragment.newInstance(account))
                .commit();
    }

    @Override
    public void cancelNewUser() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new LoginFragment())
                .commit();
    }

    @Override
    public void createNewForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new NewForumFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void logoutUser() {
        account = null;
        getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new LoginFragment())
                .commit();
    }

    @Override
    public void cancelNewForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumsFragment())
                .commit();
    }

    @Override
    public void submitNewForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumsFragment())
                .commit();
    }
}