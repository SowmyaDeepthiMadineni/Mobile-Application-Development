package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class LoginFragment extends Fragment {

    EditText emailLoginEditText, passwordLoginEditText;
    String email, password;
    FirebaseAuth mAuth;
    LoginInterface mListener;

    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        getActivity().setTitle(getResources().getString(R.string.loginTitle));

        emailLoginEditText = view.findViewById(R.id.emailLoginEditText);
        passwordLoginEditText = view.findViewById(R.id.passwordLoginEditText);
        mAuth = FirebaseAuth.getInstance();

        view.findViewById(R.id.loginButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = emailLoginEditText.getText().toString();
                password = passwordLoginEditText.getText().toString();

                if (email.isEmpty()){
                    Toast.makeText(getContext(), getResources().getString(R.string.emptyEmail), Toast.LENGTH_SHORT).show();
                }
                else if (password.isEmpty()){
                    Toast.makeText(getContext(), getResources().getString(R.string.emptyPassword), Toast.LENGTH_SHORT).show();
                }
                else{
                    mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                getLoggedInUserData(email);
                            }
                            else{
                                Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });


        view.findViewById(R.id.createAccountTextView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mListener.goToCreateNewAccount();
            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginInterface){
            mListener = (LoginInterface) context;
        }
        else{
            throw new RuntimeException(getContext().toString() + " must be implemented");
        }
    }

    public void getLoggedInUserData(String email){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Users").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot document: task.getResult()){
                                Log.d("demo", "On Successful Task: " + document.getData().toString());
                                Account account = document.toObject(Account.class);
                                ///Log.d("demo", "onComplete: "+.toString());
                                Log.d("demo", "onComplete: " + account.toString());
                                mListener.loginUser();
                            }
                        }
                        else {
                            Log.d("demo", task.getException().getMessage());
                        }
                    }
                });
    }

    interface LoginInterface{
        public void loginUser();
        public void goToCreateNewAccount();
    }
}