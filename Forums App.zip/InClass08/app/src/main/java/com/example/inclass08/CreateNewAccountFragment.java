package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class CreateNewAccountFragment extends Fragment {

    EditText CreateAccountName, CreateAccountEmail, Password;
    CreateAccountInterface mListener;
    FirebaseAuth mAuth;
    String name, email, password;
    Account user;

    public CreateNewAccountFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_create_new_account, container, false);

        getActivity().setTitle(getResources().getString(R.string.createAccountTitle));

        CreateAccountName = view.findViewById(R.id.nameCreateAccountEditText);
        CreateAccountEmail = view.findViewById(R.id.emailCreateAccountEditText);
        Password = view.findViewById(R.id.passwordCreateAccountEditText);
        mAuth = FirebaseAuth.getInstance();

        view.findViewById(R.id.cancelCreateAccountTextView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.cancelNewUser();
            }
        });


        view.findViewById(R.id.submitAccountButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = CreateAccountName.getText().toString();
                email = CreateAccountEmail.getText().toString();
                password = Password.getText().toString();

                if (name.isEmpty()){
                    Toast.makeText(getContext(), getResources().getString(R.string.emptyName), Toast.LENGTH_SHORT).show();
                }
                else if (email.isEmpty()){
                    Toast.makeText(getContext(), getResources().getString(R.string.emptyEmail), Toast.LENGTH_SHORT).show();
                }
                else if (password.isEmpty()){
                    Toast.makeText(getContext(), getResources().getString(R.string.emptyPassword), Toast.LENGTH_SHORT).show();
                }
                else{
                    mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                createUser(name, email, mAuth.getUid());
                            }
                            else{
                                Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof CreateAccountInterface){
            mListener = (CreateAccountInterface) context;
        }
        else{
            throw new RuntimeException(getContext().toString() + " must be implemented");
        }
    }

    public void createUser(String name, String email, String uid){
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("Users").add(new Account(name, email,uid))
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        mListener.createNewUser(name, email, mAuth.getUid());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    interface CreateAccountInterface{
        public void createNewUser(String name, String email,String uid);
        public void cancelNewUser();
    }
}