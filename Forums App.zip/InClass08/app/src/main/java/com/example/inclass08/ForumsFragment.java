package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;

public class ForumsFragment extends Fragment {

    ForumsInterface mListener;
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    Account user;
    private static final String ARG_USER = "ARG_USER";


    public ForumsFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static ForumsFragment newInstance(Account account) {
        ForumsFragment fragment = new ForumsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER, account);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            user = (Account) getArguments().getSerializable(ARG_USER);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ForumsInterface){
            mListener = (ForumsInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString() + " must be implemented");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_forums, container, false);

        getActivity().setTitle(getResources().getString(R.string.forumsTitle));


        view.findViewById(R.id.logoutButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                mListener.logoutUser();
            }
        });


        view.findViewById(R.id.newForumButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.createNewForum();
            }
        });

        return view;
    }

    interface ForumsInterface{
        public void createNewForum();
        public void logoutUser();
    }
}