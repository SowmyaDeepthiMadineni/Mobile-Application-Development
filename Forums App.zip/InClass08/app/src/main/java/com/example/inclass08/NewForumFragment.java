package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;


public class NewForumFragment extends Fragment {

    EditText newForumTitleEditText, forumDescriptionEditText;
    String title, description;
    NewForumInterface mListener;
    FirebaseAuth mAuth;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public NewForumFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static NewForumFragment newInstance(String param1, String param2) {
        NewForumFragment fragment = new NewForumFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof NewForumInterface){
            mListener = (NewForumInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString() + " must be implemented");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_forum, container, false);

        getActivity().setTitle(getResources().getString(R.string.newForumTitle));

        newForumTitleEditText = view.findViewById(R.id.newForumTitleEditText);
        forumDescriptionEditText = view.findViewById(R.id.forumDescriptionEditText);

        view.findViewById(R.id.cancelNewForumTextView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.cancelNewForum();
            }
        });

        view.findViewById(R.id.submitNewForumButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                title = newForumTitleEditText.getText().toString();
                description = forumDescriptionEditText.getText().toString();

                if (title.isEmpty()){
                    Toast.makeText(getActivity(), getResources().getString(R.string.emptyTitle), Toast.LENGTH_SHORT).show();
                }
                else if (description.isEmpty()){
                    Toast.makeText(getActivity(), getResources().getString(R.string.emptyDescription), Toast.LENGTH_SHORT).show();
                }
                else {
                    mAuth = FirebaseAuth.getInstance();
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    Date date = new Date();
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("title", title);
                    map.put("description", description);
                    map.put("createdAt", new Timestamp(date));
                    map.put("ownerId", mAuth.getCurrentUser().getUid());


                    DocumentReference docRef = db.collection("forums").document();
                    map.put("forumId",docRef.getId());

                    docRef.set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(getContext(), "new Forum created !!!", Toast.LENGTH_LONG).show();
                            mListener.cancelNewForum();
                        }
                    });

                }

            }
        });


        return view;
    }

    interface NewForumInterface{
        public void cancelNewForum();
        public void submitNewForum();
    }

    public void createForum(String title, Account account, String description){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy  HH:mm");

        HashMap<String, Forum> forumsList = new HashMap<>();
        forumsList.put(account.getEmail(), new Forum(title, account.uid, dateFormat.format(date), description));

        db.collection("Forums").add(forumsList)
                .addOnSuccessListener(getActivity(), new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(getActivity(), getResources().getString(R.string.newForumSuccessfull), Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(getActivity(), new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}