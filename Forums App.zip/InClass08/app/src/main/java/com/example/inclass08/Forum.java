package com.example.inclass08;

import java.io.Serializable;


public class Forum implements Serializable {
    private String title,account_uid;
    private String createdAt;
    private String description;
    private long forumId;

    public Forum(String title, String account_uid, String createdAt, String description) {
        this.title = title;
        this.account_uid = account_uid;
        this.createdAt = createdAt;
        this.description = description;
        this.forumId = MainActivity.FORUM_ID_COUNTER++;
    }

    public long getForumId() {
        return forumId;
    }

    public String getTitle() {
        return title;
    }

    public String getAccount_uid() {
        return account_uid;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getDescription() {
        return description;
    }



    @Override
    public String toString() {
        return "Forum{" +
                "title='" + title + '\'' +
                ", createdBy=" + account_uid +
                ", createdAt=" + createdAt +
                ", description='" + description + '\'' +
                ", forumId=" + forumId +
                '}';
    }
}
