
package com.example.inclass07;

import java.io.Serializable;

public class Contact implements Serializable {
    String Cid, Name, Email, Phone, PhoneType;

    public String getCid() {
        return Cid;
    }

    public void setCid(String cid) {
        Cid = cid;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getPhoneType() {
        return PhoneType;
    }

    public void setPhoneType(String phoneType) {
        PhoneType = phoneType;
    }

    public Contact() {
    }

    public Contact(String cid, String name, String email, String phone, String phoneType) {
        Cid = cid;
        Name = name;
        Email = email;
        Phone = phone;
        PhoneType = phoneType;
    }
}
