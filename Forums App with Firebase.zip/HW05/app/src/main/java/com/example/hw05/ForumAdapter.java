package com.example.hw05;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ForumAdapter extends RecyclerView.Adapter<ForumAdapter.ForumListViewHolder> {
    String TAG = "demo";
    ArrayList<Forum> Lists;
    ForumAdapter.ForumListAdapterInterface listener;

    String userId;

    public ForumAdapter(ArrayList<Forum> Data, String id, ForumAdapter.ForumListAdapterInterface ListInterface) {
        this.Lists = Data;
        this.listener = ListInterface;
        this.userId = id;
    }


    @NonNull
    @Override
    public ForumListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum_list_layout, parent, false);
        ForumListViewHolder viewHolder = new ForumListViewHolder(view, listener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ForumListViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Forum selectedForumData = Lists.get(position);
        holder.title.setText(selectedForumData.getForumTitle());
        holder.author.setText(selectedForumData.getName());
        if (selectedForumData.getDetail().length() > 200) {
            holder.desc.setText(selectedForumData.getDetail().substring(0, 200) + " ...");
        } else {
            holder.desc.setText(selectedForumData.getDetail());
        }

        holder.likes.setText(selectedForumData.getLikes() + " Likes |");
        holder.date.setText(selectedForumData.getDateValue());

        Log.d(TAG, "onBindViewHolder: " + userId);
        Log.d(TAG, "onBindViewHolder: forum id " + selectedForumData.getUserID());

        if (selectedForumData.getUserID().equals(userId)) {
            holder.delete.setVisibility(View.VISIBLE);
        } else {
            holder.delete.setVisibility(View.GONE);
        }

        if (selectedForumData.getlikeBy().contains(userId)) {
            holder.liked.setVisibility(View.VISIBLE);
            holder.notLiked.setVisibility(View.GONE);
        } else {
            holder.liked.setVisibility(View.GONE);
            holder.notLiked.setVisibility(View.VISIBLE);
        }
        holder.position = position;
        holder.forum = selectedForumData;
    }

    @Override
    public int getItemCount() {
        return Lists.size();
    }

    public static class ForumListViewHolder extends RecyclerView.ViewHolder {
        TextView title, author, desc, likes, date;
        ImageView delete, liked, notLiked;
        int position;
        Forum forum;
        ForumAdapter.ForumListAdapterInterface forumListListener;

        @SuppressLint("ResourceType")
        public ForumListViewHolder(@NonNull View itemView, ForumAdapter.ForumListAdapterInterface AppListListener) {
            super(itemView);
            this.forumListListener = AppListListener;
            title = itemView.findViewById(R.id.forumTitle);
            author = itemView.findViewById(R.id.forumAuthor);
            desc = itemView.findViewById(R.id.forumDescription);
            likes = itemView.findViewById(R.id.numberOfLikes);
            date = itemView.findViewById(R.id.forumdate);
            delete = itemView.findViewById(R.id.deleteImageView);
            notLiked = itemView.findViewById(R.id.notLikedImageView);
            liked = itemView.findViewById(R.id.likeImageView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    forumListListener.getForumDetails(forum);
                }
            });
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    forumListListener.deleteForum(forum.getID());
                }
            });

            liked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    forumListListener.LikeDislikeForum("Dislike", forum.getID(), forum.getlikeBy());
                }
            });

            notLiked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    forumListListener.LikeDislikeForum("Like", forum.getID(), forum.getlikeBy());
                }
            });
        }


    }

    interface ForumListAdapterInterface {
        void getForumDetails(Forum forum);

        void deleteForum(String id);

        void LikeDislikeForum(String action, String id, ArrayList<String> like);
    }
}

