package com.example.hw05;

public class Comment {

    String forumID,date,comment,writer,userID,id;

    @Override
    public String toString() {
        return "forumComment{" +
                "forumID='" + forumID + '\'' +
                ", dateValue='" + date + '\'' +
                ", comment='" + comment + '\'' +
                ", writer='" + writer + '\'' +
                ", userID='" + userID + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getForumID() {
        return forumID;
    }

    public void setForumID(String forumID) {
        this.forumID = forumID;
    }

    public String getDateValue() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
