package com.example.hw05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ForumFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ForumFragment extends Fragment implements ForumAdapter.ForumListAdapterInterface {


    String userName,userId;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    ForumAdapter adapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ForumInterface ForumListener;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ForumFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ForumFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ForumFragment newInstance(String param1, String param2) {
        ForumFragment fragment = new ForumFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_forum, container, false);

        getActivity().setTitle(getResources().getString(R.string.forums_label));
        getUserName();

        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        recyclerView = view.findViewById(R.id.recyclerViewForumList);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        getData();


        view.findViewById(R.id.logoutButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                ForumListener.logoutUser();
            }
        });

        view.findViewById(R.id.newForumButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ForumListener.createNewForum(userName);
            }
        });


        return view;
    }

    public void getUserName() {

        db.collection("User")
                .whereEqualTo("userId", FirebaseAuth.getInstance().getCurrentUser().getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                userName = (String) document.getData().get("name");

                            }
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " : " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void getData() {
        db.collection("forum").get()
                .addOnCompleteListener(getActivity(), new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            ArrayList<Forum> forumList = new ArrayList<>();
                            for (QueryDocumentSnapshot data : task.getResult()) {
                                ArrayList<String> like = (ArrayList<String>) data.getData().get("likeCount");
                                Forum forum = new Forum();
                                forum.setID(data.getId());
                                forum.setUserID((String) data.getData().get("userID"));
                                forum.setDateValue((String) data.getData().get("Date"));
                                forum.setDetail((String) data.getData().get("forumDescription"));
                                forum.setName((String) data.getData().get("userName"));
                                forum.setForumTitle((String) data.getData().get("title"));
                                forum.setLikes(String.valueOf(like.size()));
                                forum.setLikeBy(like);
                                forumList.add(forum);
                            }


                            adapter = new ForumAdapter(forumList, userId, ForumFragment.this);
                            recyclerView.setAdapter(adapter);
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.error_message), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ForumFragment.ForumInterface) {
            ForumListener = (ForumFragment.ForumInterface) context;
        } else {
            throw new RuntimeException(context.toString() + getResources().getString(R.string.ErrorContext));
        }
    }


    @Override
    public void getForumDetails(Forum forum) {
        ForumListener.viewForumDetail(forum.getID(), forum, userName);
    }

    @Override
    public void deleteForum(String id) {
        db.collection("forum").document(id)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        getData();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " : " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    public void LikeDislikeForum(String action, String id, ArrayList<String> Like) {
        Map<String, Object> forumDetails = new HashMap<>();
        if (action.equals("Dislike")) {
            Like.remove(userId);
        } else if (action.equals("Like")) {
            Like.add(userId);
        }
        forumDetails.put("likeCount", Like);
        db.collection("forum").document(id)
                .update(forumDetails)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        getData();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    interface ForumInterface {
        void logoutUser();
        void viewForumDetail(String id, Forum forum, String name);
        void createNewForum(String Name);
    }

}
