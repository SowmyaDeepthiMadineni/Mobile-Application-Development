package com.example.hw05;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewForumFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewForumFragment extends Fragment {

    private static final String NAME = "NAME";
    private String Name;
    EditText name, desc;
    String titleValue, descValue;
    NewForumFragmentInterface listener;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";



    public NewForumFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static NewForumFragment newInstance(String param1) {
        NewForumFragment fragment = new NewForumFragment();
        Bundle args = new Bundle();
        args.putString(NAME, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            Name = getArguments().getString(NAME);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_forum, container, false);

        getActivity().setTitle(getResources().getString(R.string.new_forum_label));
        name = view.findViewById(R.id.forumTitle);
        desc = view.findViewById(R.id.forumDesc);
        Button submit=view.findViewById(R.id.submitForumButton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleValue = name.getText().toString();
                descValue = desc.getText().toString();
                if (titleValue.isEmpty() || descValue.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage(R.string.error_mandatory_fields)
                            .setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    Date date = new Date();
                    Map<String, Object> userDetails = new HashMap<>();
                    userDetails.put("forumDescription", descValue);
                    userDetails.put("title", titleValue);
                    userDetails.put("userID", FirebaseAuth.getInstance().getCurrentUser().getUid());
                    userDetails.put("userName", Name);
                    userDetails.put("Date", formatter.format(date));
                    userDetails.put("likeCount", new ArrayList<String>());

                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    db.collection("forum").add(userDetails)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    listener.addNewlyCreatedForum();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                    builder.setMessage(e.getMessage())
                                            .setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {

                                                }
                                            });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                }
                            });
                }

            }
        });

        view.findViewById(R.id.cancelNewForum).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.cancelNewForum();
            }
        });
        return view;
    }



    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof NewForumFragmentInterface) {
            listener = (NewForumFragmentInterface) context;
        } else {
            throw new RuntimeException(context.toString() + getResources().getString(R.string.ErrorContext));
        }
    }

    interface NewForumFragmentInterface {
        void addNewlyCreatedForum();

        void cancelNewForum();
    }
}