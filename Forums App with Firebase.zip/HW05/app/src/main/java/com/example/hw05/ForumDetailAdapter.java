package com.example.hw05;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ForumDetailAdapter extends RecyclerView.Adapter<ForumDetailAdapter.ListViewHolder> {
        ArrayList<Comment> CommentList;
        String userId;
        ForumDetailListener forumDetailListener;

        public ForumDetailAdapter(ArrayList<Comment> Data, String id, ForumDetailListener forumDetailListener) {
            this.CommentList = Data;
            this.userId = id;
            this.forumDetailListener = forumDetailListener;
        }

        @NonNull
        @Override
        public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum_view_layout, parent, false);
            ForumDetailAdapter.ListViewHolder viewHolder = new ForumDetailAdapter.ListViewHolder(view, forumDetailListener);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ListViewHolder holder, @SuppressLint("RecyclerView") int position) {

            holder.commentDesc.setText(CommentList.get(position).getComment());
            holder.writerName.setText(CommentList.get(position).getWriter());
            holder.date.setText(CommentList.get(position).getDateValue());


            if (CommentList.get(position).getUserID().equals(userId)) {
                holder.delete.setVisibility(View.VISIBLE);
            } else {
                holder.delete.setVisibility(View.GONE);
            }

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    forumDetailListener.deleteComment(String.valueOf(CommentList.get(position).getID()));
                }
            });


        }

        @Override
        public int getItemCount() {
            return CommentList.size();
        }

        public static class ListViewHolder extends RecyclerView.ViewHolder {

            TextView writerName, commentDesc, date;
            ImageView delete;
            ForumDetailListener forumDetailListener;

            public ListViewHolder(@NonNull View itemView, ForumDetailListener forumDetailListener) {
                super(itemView);
                this.forumDetailListener = forumDetailListener;
                writerName = itemView.findViewById(R.id.commentWriter);
                commentDesc = itemView.findViewById(R.id.commentDesc);
                date = itemView.findViewById(R.id.commentDate);
                delete = itemView.findViewById(R.id.deleteCommentImageView);
            }
        }

        interface ForumDetailListener {
            void deleteComment(String commentId);
        }
    }

