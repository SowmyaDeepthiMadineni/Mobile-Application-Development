package com.example.hw05;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginInterface, CreateNewAccountFragment.CreateInterface, ForumFragment.ForumInterface, NewForumFragment.NewForumFragmentInterface{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseAuth mAuth;

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.containerView, new LoginFragment())
                    .commit();
        } else {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.containerView, new ForumFragment())
                    .commit();
        }
    }

    @Override
    public void cancelNewAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new LoginFragment())
                .commit();

    }

    @Override
    public void addNewlyCreatedUser() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumFragment())
                .commit();

    }

    @Override
    public void login() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumFragment())
                .commit();
    }

    @Override
    public void registerNewAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new CreateNewAccountFragment())
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void logoutUser() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new LoginFragment())
                .commit();

    }

    @Override
    public void viewForumDetail(String id, Forum forum, String name) {

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.containerView, ForumDetailFragment.newInstance(id, forum, name))
                    .addToBackStack(null)
                    .commit();


    }

    @Override
    public void createNewForum(String Name) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, NewForumFragment.newInstance(Name))
                .commit();

    }

    @Override
    public void addNewlyCreatedForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumFragment())
                .commit();


    }

    @Override
    public void cancelNewForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, new ForumFragment())
                .commit();

    }
}