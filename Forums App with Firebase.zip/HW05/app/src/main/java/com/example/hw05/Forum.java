package com.example.hw05;

import java.io.Serializable;
import java.util.ArrayList;

public class Forum implements Serializable {

    String name,userID,desc,forumTitle,noOflikes,date,id;
    ArrayList<String> likeBy;

    public Forum() {
    }

    public Forum(String name, String userID, String detail, String forumTitle, String noOflikes, String dateValue, ArrayList<String> likeBy) {
        this.name = name;
        this.userID = userID;
        this.desc = detail;
        this.forumTitle = forumTitle;
        this.noOflikes = noOflikes;
        this.date = dateValue;
        this.likeBy = likeBy;
    }

    public ArrayList<String> getlikeBy() {
        return likeBy;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setLikeBy(ArrayList<String> likeBy) {
        this.likeBy = likeBy;
    }

    public String getDateValue() {
        return date;
    }

    public void setDateValue(String dateValue) {
        this.date = dateValue;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getDetail() {
        return desc;
    }

    public void setDetail(String desc) {
        this.desc = desc;
    }

    public String getForumTitle() {
        return forumTitle;
    }

    public void setForumTitle(String forumTitle) {
        this.forumTitle = forumTitle;
    }

    public String getLikes() {
        return noOflikes;
    }

    public void setLikes(String noOflikes) {
        this.noOflikes = noOflikes;
    }

    @Override
    public String toString() {
        return "forum{" +
                "Name='" + name + '\'' +
                ", userID='" + userID + '\'' +
                ", detail='" + desc + '\'' +
                ", forumTitle='" + forumTitle + '\'' +
                ", noOflikes='" + noOflikes + '\'' +
                ", dateValue='" + date + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

}
