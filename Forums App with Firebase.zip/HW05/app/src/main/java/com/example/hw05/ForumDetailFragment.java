package com.example.hw05;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ForumDetailFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ForumDetailFragment extends Fragment implements ForumDetailAdapter.ForumDetailListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM_FORUM_ID = "ARG_PARAM_FORUM_ID";
    private static final String ARG_PARAM2 = "ARG_PARAM2";
    private static final String ARG_PARAM3 = "ARG_PARAM3";

    // TODO: Rename and change types of parameters
    private String forumId,author;
    private Forum mParam2;


    TextView writerName, forumName, comments, description, commentLabel;
    EditText addComment;
    ForumDetailAdapter adapter;
    String UserId;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    public ForumDetailFragment() {
        // Required empty public constructor
    }

    public static ForumDetailFragment newInstance(String param1, Forum param2, String param3) {
        ForumDetailFragment fragment = new ForumDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_FORUM_ID, param1);
        args.putSerializable(ARG_PARAM2, param2);
        args.putString(ARG_PARAM3, param3);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            forumId = getArguments().getString(ARG_PARAM_FORUM_ID);
            mParam2 = (Forum) getArguments().getSerializable(ARG_PARAM2);
            author = getArguments().getString(ARG_PARAM3);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_forum_detail, container, false);
        getActivity().setTitle(getResources().getString(R.string.forum_label));
        UserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        recyclerView = view.findViewById(R.id.recyclerViewCommentList);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        writerName = view.findViewById(R.id.forumAuthor);
        commentLabel = view.findViewById(R.id.commentLabel);
        forumName = view.findViewById(R.id.forumTitle);
        comments = view.findViewById(R.id.numberOfComments);
        description = view.findViewById(R.id.forumDescription);

        addComment = view.findViewById(R.id.addComment);

        description.setText(mParam2.getDetail());
        description.setMovementMethod(new ScrollingMovementMethod());
        writerName.setText(mParam2.getName());
        forumName.setText(mParam2.getForumTitle());

        getComment();

        view.findViewById(R.id.postButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!addComment.getText().toString().isEmpty()) {
                    addAcomment(addComment.getText().toString());
                }
            }
        });

        return view;
    }

    public void getComment() {
        db.collection("forumComment")

                .whereEqualTo("forumId", forumId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            ArrayList<Comment> dataList = new ArrayList<>();
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Comment forumCommentData = new Comment();
                                forumCommentData.setWriter((String) document.getData().get("author"));
                                forumCommentData.setComment((String) document.getData().get("comment"));
                                forumCommentData.setDate((String) document.getData().get("date"));
                                forumCommentData.setForumID((String) document.getData().get("forumId"));
                                forumCommentData.setUserID((String) document.getData().get("userId"));
                                forumCommentData.setID(document.getId());

                                dataList.add(forumCommentData);
                            }

                            adapter = new ForumDetailAdapter(dataList, UserId, ForumDetailFragment.this);
                            recyclerView.setAdapter(adapter);
                        }
                        else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " : " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    @Override
    public void deleteComment(String commentId) {
        db.collection("forumComment").document(commentId)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        getComment();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " : " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void addAcomment(String comment){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        Map<String, Object> userDetails = new HashMap<>();
        userDetails.put("comment", comment);
        userDetails.put("date", formatter.format(date));
        userDetails.put("forumId", forumId);
        userDetails.put("author", author);
        userDetails.put("userId", FirebaseAuth.getInstance().getCurrentUser().getUid());
        db.collection("forumComment")
                .add(userDetails)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        getComment();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " " + e.getMessage(), Toast.LENGTH_LONG).show();                                                    }
                });


    }
}