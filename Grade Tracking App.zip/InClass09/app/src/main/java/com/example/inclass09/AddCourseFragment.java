package com.example.inclass09;

import static android.widget.Toast.LENGTH_SHORT;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class AddCourseFragment extends Fragment {

    TextView cancel;
    EditText courseName, courseNumber, creditHours;
    Button submit;
    RadioGroup courseGrades;
    CoursesDatabase coursedb;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AddCourseFragment(CoursesDatabase database) {
        this.coursedb = database;
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_course, container, false);

        getActivity().setTitle(getResources().getString(R.string.addcourse));

        cancel = view.findViewById(R.id.cancel);
        courseName=view.findViewById(R.id.EditTextCourseName);
        courseNumber=view.findViewById(R.id.EditTextCourseNumber);
        creditHours=view.findViewById(R.id.EditTextcreditHours);
        submit = view.findViewById(R.id.submitButton);
        courseGrades = view.findViewById(R.id.GradesRadioGroup);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    String CourseName = String.valueOf(courseName.getText());
                    String CourseNum = String.valueOf(courseNumber.getText());
                    long CreditHours = Integer.parseInt(String.valueOf(creditHours.getText()));
                    int checkedvalue = courseGrades.getCheckedRadioButtonId();
                    if(CourseName.isEmpty()){
                        showAlertDialog(getResources().getString(R.string.validname));
                    }else if(CourseNum.isEmpty()){
                        showAlertDialog(getResources().getString(R.string.validcoursenumber));
                    }else if(CreditHours> 0) {
                        if(checkedvalue == R.id.A){
                            coursedb.courseDao().insertall(new Courses(CourseNum, CourseName, "A", (long) 4.0, CreditHours));
                        }else if(checkedvalue == R.id.B){
                            coursedb.courseDao().insertall(new Courses(CourseNum, CourseName, "B", (long) 3.0, CreditHours));
                        }else if(checkedvalue == R.id.C){
                            coursedb.courseDao().insertall(new Courses(CourseNum, CourseName, "C", (long) 2.0,CreditHours));
                        }else if(checkedvalue==R.id.D){
                            coursedb.courseDao().insertall(new Courses(CourseNum, CourseName, "D", (long) 1.0,CreditHours));
                        }else if(checkedvalue == R.id.F){
                            coursedb.courseDao().insertall(new Courses(CourseNum, CourseName, "F", (long) 0.0, CreditHours));
                        }
                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.rootView, new GradeScreenFragment(coursedb)).commit();
                    }

                }catch (Exception e){
                    Toast.makeText(getContext(), e.getMessage(), LENGTH_SHORT).show();
                }


            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().popBackStack();
            }
        });


        return view;
    }

    void showAlertDialog(String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(message)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}