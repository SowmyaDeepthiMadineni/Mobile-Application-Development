package com.example.inclass09;

import androidx.room.Database;
import androidx.room.RoomDatabase;


@Database(entities = {Courses.class},version = 1)
public abstract class CoursesDatabase extends RoomDatabase {
    public abstract CoursesDao courseDao();
}