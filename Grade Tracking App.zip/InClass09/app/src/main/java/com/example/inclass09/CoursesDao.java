package com.example.inclass09;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CoursesDao {

    @Query("SELECT * FROM coursesTable ")
    List<Courses> getAll();

    @Query("SELECT * FROM coursesTable WHERE _id = :id LIMIT 1")
    Courses findById(int id);

    @Insert
    void insertall(Courses... courses);

    @Delete
    void delete(Courses course);




}
