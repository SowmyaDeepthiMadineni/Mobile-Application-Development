package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements GradeScreenFragment.GradesInterface{

    CoursesDatabase coursedb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coursedb = Room.databaseBuilder(this, CoursesDatabase.class, "course.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration().build();


        getSupportFragmentManager().beginTransaction().add(R.id.rootView, new GradeScreenFragment(coursedb)).commit();
    }

    @Override
    public void AddACourse() {
        getSupportFragmentManager().beginTransaction().replace(R.id.rootView, new AddCourseFragment(coursedb)).addToBackStack(null).commit();
    }
}