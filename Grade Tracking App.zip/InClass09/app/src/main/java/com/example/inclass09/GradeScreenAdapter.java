package com.example.inclass09;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class GradeScreenAdapter extends ArrayAdapter<Courses> {
    List<Courses> ListofCourses;
    adapterListener Listener;
    public GradeScreenAdapter(@NonNull Context context, int resource, @NonNull List<Courses> objects, adapterListener Listener) {
        super(context, resource, objects);
        this.Listener = Listener;
        this.ListofCourses = objects;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final ViewHolder viewHolder;
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.adapter, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final Courses course = ListofCourses.get(position);

        viewHolder.courseNum.setText(course.courseNumber+"");
        viewHolder.creditHours.setText(course.creditHours+" Credits Hours");
        viewHolder.courseName.setText(course.courseName);
        viewHolder.courseGrade.setText(course.courseGrade);

        viewHolder.rubbishBin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListofCourses.remove(course);
                Listener.CourseDeletion(course);
            }
        });
        return convertView;
    }

    public interface adapterListener{

        void CourseDeletion(Courses course);
    }

    @Override
    public int getCount() {

        return ListofCourses.size();
    }

    public static class ViewHolder {
        TextView courseName, courseNum, creditHours, courseGrade;
        ImageView rubbishBin;


        ViewHolder(View view) {
            courseNum = view.findViewById(R.id.CourseNum);
            courseGrade = view.findViewById(R.id.CourseGrade);
            courseName = view.findViewById(R.id.CourseName);
            creditHours = view.findViewById(R.id.CreditHours);
            rubbishBin = view.findViewById(R.id.rubbishbin);
        }
    }
}


