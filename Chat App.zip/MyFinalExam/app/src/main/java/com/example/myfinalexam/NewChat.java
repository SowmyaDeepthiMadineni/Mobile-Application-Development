package com.example.myfinalexam;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewChat#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewChat extends Fragment {
    private static final String NAME = "NAME";
    private String Name;
    EditText  desc;
    String  descValue;
    NewChatInterface listener;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public NewChat() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.

     * @return A new instance of fragment NewChat.
     */
    // TODO: Rename and change types and number of parameters
    public static NewChat newInstance(String param1) {
        NewChat fragment = new NewChat();
        Bundle args = new Bundle();
        args.putString(NAME, param1);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            Name = getArguments().getString(NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_new_chat, container, false);
        getActivity().setTitle("New Chat");

        desc = view.findViewById(R.id.Message);
        Button submit=view.findViewById(R.id.submitButton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                descValue = desc.getText().toString();
                if ( descValue.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage(R.string.error_mandatory_fields)
                            .setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    Date date = new Date();
                    Map<String, Object> userDetails = new HashMap<>();
                    userDetails.put("Message", descValue);

                    userDetails.put("userID", FirebaseAuth.getInstance().getCurrentUser().getUid());
                    userDetails.put("userName", Name);
                    userDetails.put("Date", formatter.format(date));


                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    db.collection("chats").add(userDetails)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    listener.addNewlyCreatedChat();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                    builder.setMessage(e.getMessage())
                                            .setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {

                                                }
                                            });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                }
                            });
                }

            }
        });

        view.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.cancelNewChart();
            }
        });
        return view;
    }




   public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof NewChatInterface) {
            listener = (NewChatInterface) context;
        } else {
            throw new RuntimeException(context.toString() + getResources().getString(R.string.ErrorContext));
        }
    }

    interface NewChatInterface {
        void addNewlyCreatedChat();

        void cancelNewChart();


    }
}