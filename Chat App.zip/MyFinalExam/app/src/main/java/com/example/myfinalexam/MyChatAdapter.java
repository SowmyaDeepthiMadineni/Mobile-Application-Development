package com.example.myfinalexam;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.common.collect.Lists;

import java.util.ArrayList;
public class MyChatAdapter extends RecyclerView.Adapter<MyChatAdapter.ChatListViewHolder>{

    String TAG = "demo";
    ArrayList<Chats> Lists;
    MyChatAdapter.ChatListAdapterInterface listener;

    String userId;

    public MyChatAdapter(ArrayList<Chats> chatList, String userId, MyChatAdapter.ChatListAdapterInterface myChats) {
        this.Lists = chatList;
        this.listener = (ChatListAdapterInterface) myChats;
        this.userId = userId;

    }

    @NonNull
    @Override
    public ChatListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chatlist, parent, false);
        ChatListViewHolder viewHolder = new ChatListViewHolder(view, listener);
        return viewHolder;

    }

    @Override
    
    public void onBindViewHolder(@NonNull ChatListViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Chats selectedChatData = Lists.get(position);

        holder.author.setText(selectedChatData.getAuthor());
        /*if (selectedChatData.getChat_desc().length() > 200) {
            holder.desc.setText(selectedChatData.getChat_desc().substring(0, 200) + " ...");
        } else {
            holder.desc.setText(selectedChatData.getChat_desc());
        }*/

        
        holder.date.setText(selectedChatData.getDate());

        Log.d(TAG, "onBindViewHolder: " + userId);
        Log.d(TAG, "onBindViewHolder: forum id " + selectedChatData.getUserId());

       
        holder.position = position;
        holder.chats = selectedChatData;

    }

    @Override
    public int getItemCount() {
        return Lists.size();
    }

    public class ChatListViewHolder extends RecyclerView.ViewHolder {
        TextView  author, desc,  date;
        int position;
        Chats chats;
        ChatListAdapterInterface chatListListener;
        public ChatListViewHolder(View view, ChatListAdapterInterface listener) {
            super(view);

            this.chatListListener = listener;

            author = itemView.findViewById(R.id.Author);
            desc = itemView.findViewById(R.id.ChatDescription);

            date = itemView.findViewById(R.id.chatdate);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chatListListener.getChatDetails(chats);
                }
            });
        }

    }

    interface ChatListAdapterInterface {
        void getChatDetails(Chats chats);


    }
}
