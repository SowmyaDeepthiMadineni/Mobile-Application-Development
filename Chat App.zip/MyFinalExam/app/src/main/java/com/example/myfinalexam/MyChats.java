package com.example.myfinalexam;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MyChats#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MyChats extends Fragment  implements MyChatAdapter.ChatListAdapterInterface{
    String userName,userId;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    MyChatAdapter adapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ChatInterface ChatListener;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MyChats() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MyChats.
     */
    // TODO: Rename and change types and number of parameters
    public static MyChats newInstance(String param1, String param2) {
        MyChats fragment = new MyChats();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_my_chats, container, false);

        getActivity().setTitle(getResources().getString(R.string.Chats));
        getUserName();

        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        recyclerView = view.findViewById(R.id.recyclerViewForumList);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        getData();


        view.findViewById(R.id.logoutButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                ChatListener.logoutUser();
            }
        });

        view.findViewById(R.id.newChatButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChatListener.createNewChat(userName);
            }
        });


        return view;
    }

    public void getUserName() {

        db.collection("User")
                .whereEqualTo("userId", FirebaseAuth.getInstance().getCurrentUser().getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                userName = (String) document.getData().get("name");

                            }
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.error_message) + " : " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void getData() {
        db.collection("chats").get()
                .addOnCompleteListener(getActivity(), new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            ArrayList<Chats> chatList = new ArrayList<>();
                            for (QueryDocumentSnapshot data : task.getResult()) {
                                ArrayList<String> like = (ArrayList<String>) data.getData().get("likeCount");
                                Chats chats = new Chats();
                                chats.setId(data.getId());
                                chats.setUserId((String) data.getData().get("userID"));
                                chats.setDate((String) data.getData().get("Date"));
                                chats.setChat_desc((String) data.getData().get("ChatDescription"));
                                chats.setAuthor((String) data.getData().get("Name"));
                                chatList.add(chats);
                            }

                            adapter=new MyChatAdapter(chatList,userId,MyChats.this);

                            recyclerView.setAdapter(adapter);
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.error_message), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof MyChats.ChatInterface) {
            ChatListener = (MyChats.ChatInterface) context;
        } else {
            throw new RuntimeException(context.toString() + getResources().getString(R.string.ErrorContext));
        }
    }



    public void getChatDetails(Chats chats) {
        ChatListener.viewChatDetail(chats.getId(), chats, userName);
    }




    interface ChatInterface {
        void logoutUser();
        void viewChatDetail(String id, Chats forum, String name);
        void createNewChat(String Name);
    }

}
