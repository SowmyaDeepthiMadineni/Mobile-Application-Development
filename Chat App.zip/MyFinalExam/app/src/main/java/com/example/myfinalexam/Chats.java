package com.example.myfinalexam;

import java.io.Serializable;
import java.util.ArrayList;

public class Chats implements Serializable {
    String author,chat_desc,date,id,userId;

    public Chats() {
    }

    public Chats(String author, String userId, String chat_desc, String date) {
        this.author = author;
        this.userId = userId;
        this.chat_desc = chat_desc;

        this.date = date;

    }
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getChat_desc() {
        return chat_desc;
    }

    public void setChat_desc(String chat_desc) {
        this.chat_desc = chat_desc;
    }



    @Override
    public String toString() {
        return "Chats{" +
                "author='" + author + '\'' +
                ", chat_desc='" + chat_desc + '\'' +
                ", date='" + date + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
