//InClass05
//Group1-12
//Sowmya Deepthi Madineni
//Category_Fragment.java

package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Category_Fragment extends Fragment {

    private static final String ARG_TOKEN = "TOKEN";
    private String token;
    ListView AppCategoriesView;
    CategoriesInterface categoriesInterface;
    ArrayAdapter<String> adapter;


    public Category_Fragment() {
    }

    // TODO: Rename and change types and number of parameters
    public static Category_Fragment newInstance(String token) {
        Category_Fragment fragment = new Category_Fragment ();
        Bundle args = new Bundle();
        args.putString(ARG_TOKEN, token);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.token = getArguments().getString(ARG_TOKEN);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category_, container, false);
        AppCategoriesView = view.findViewById(R.id.categories);
        getActivity().setTitle("App Categories");

        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1, DataServices.getAppCategories());
        AppCategoriesView.setAdapter(adapter);

        AppCategoriesView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                categoriesInterface.ListFragment(token,
                        adapter.getItem(position));
            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof CategoriesInterface){
            categoriesInterface = (CategoriesInterface) context;
        }
        else {
            throw new RuntimeException( String.valueOf ( getContext() ) );
        }
    }

    public interface CategoriesInterface{
        public void ListFragment(String token, String categoryName);
    }
}