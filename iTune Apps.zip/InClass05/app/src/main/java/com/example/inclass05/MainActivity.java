//InClass05
//Group1-12
//Sowmya Deepthi Madineni
//MainActivity.java

package com.example.inclass05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements Category_Fragment.CategoriesInterface,AppList_Fragment.ListInterface{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView , new Category_Fragment ())
                .commit();
    }


    public void DetailsFragment(DataServices.App appData) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , AppDetails_Fragment.newInstance(appData))
                .addToBackStack(null)
                .commit();
        setTitle("App Details");
    }

    public void ListFragment(String token, String categoryName) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , AppList_Fragment.newInstance(token, categoryName))
                .addToBackStack(null)
                .commit();
    }


}