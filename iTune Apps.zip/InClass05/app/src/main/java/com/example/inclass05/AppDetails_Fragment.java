
//InClass05
//Group1-12
//Sowmya Deepthi Madineni
//AppDetails_fragment.java

package com.example.inclass05;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class AppDetails_Fragment extends Fragment {

    private static final String ARG_APP_DATA = "APP_DATA";
    DataServices.App appDetails;
    TextView AppName, ArtistName, ReleaseDate;
    ListView Genre;
    ArrayAdapter<String> arrayAdapter;

    public AppDetails_Fragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static AppDetails_Fragment newInstance(DataServices.App appData) {
        AppDetails_Fragment fragment = new AppDetails_Fragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_APP_DATA, appData);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            appDetails = (DataServices.App) getArguments().getSerializable(ARG_APP_DATA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_app_details_ , container, false);

        Genre = view.findViewById(R.id.AppList );
        AppName = view.findViewById(R.id.AppName );
        ArtistName = view.findViewById(R.id.ArtistName );
        ReleaseDate = view.findViewById(R.id.ReleaseDate );

        AppName.setText(String.valueOf(appDetails.name));
        ArtistName.setText(String.valueOf(appDetails.artistName));
        ReleaseDate.setText(String.valueOf(appDetails.releaseDate));

        arrayAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1, appDetails.genres);
        Genre.setAdapter(arrayAdapter);
        return view;

    }
}