//InClass05
//Group1-12
//Sowmya Deepthi Madineni
//Applist_Fragment.java

package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

public class AppList_Fragment extends Fragment {

    private static final String ARG_TOKEN = "TOKEN";
    private static final String ARG_CATEGORY_NAME = "CATEGORY_NAME";

    private String Category;
    private String token;
    ListView selectedlist;
    ListInterface listinterface;
    itunesAdapter iTunes;

    public AppList_Fragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static AppList_Fragment newInstance(String token, String categoryName) {
        AppList_Fragment fragment = new AppList_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_TOKEN, token);
        args.putString(ARG_CATEGORY_NAME, categoryName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString(ARG_TOKEN);
            Category = getArguments().getString(ARG_CATEGORY_NAME);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_app_list_ , container, false);
        selectedlist = view.findViewById(R.id.List_of_Apps );
        iTunes = new itunesAdapter (getActivity(), R.layout.adapter , DataServices.getAppsByCategory(Category));
        selectedlist.setAdapter(iTunes);

        selectedlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DataServices.App appData = iTunes.getItem(position);
                listinterface.DetailsFragment(appData);
            }
        });
        return view;
        // Inflate the layout for this fragment

    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ListInterface){
            listinterface = (ListInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString());
        }
    }
    public interface ListInterface {
        public void DetailsFragment(DataServices.App appData);
    }
}