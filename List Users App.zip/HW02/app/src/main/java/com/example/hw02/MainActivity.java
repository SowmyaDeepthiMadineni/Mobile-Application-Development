//Assignment-HW02
//Sowmya deepthi Madineni
//MainActivity.java

package com.example.hw02;

import androidx.appcompat.app.AppCompatActivity;

import android.icu.text.CaseMap;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity implements UsersFragment.UserInterface,FilterByState.FilterstateInterface {
    ArrayList<String> filteredstates= new ArrayList<>();
    ArrayList<DataServices.User> filteredUsers=new ArrayList<DataServices.User>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new UsersFragment(filteredUsers))
                .commit();
        setTitle("users");
    }


    public void FilterByStateFragment(ArrayList<DataServices.User> users) {
        Set<String> states1 = new TreeSet<>();

        for (DataServices.User user : users) {
            states1.add(user.state);
        }
        filteredstates = new ArrayList<>(states1);
        filteredstates.add(0, "All States");
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new FilterByState(filteredstates, users))
                .addToBackStack(null)
                .commit();
        setTitle("Filter By State");
    }
    public void UsersFragment(){
        getSupportFragmentManager().beginTransaction().add(R.id.rootView,new UsersFragment(filteredUsers)).commit();
    }

    public void positionClicked(int position,ArrayList<DataServices.User> users) {
        String selected_state = filteredstates.get(position);
        ArrayList<DataServices.User> selected = new ArrayList<>();
        if(position == 0) {
            UsersFragment();
            setTitle("Users");
        }else{
            for (DataServices.User user : users) {
                if (user.state.equals(selected_state)) {
                    selected.add(user);
                }
            }
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.rootView, new UsersFragment(selected))
                    .commit();
        }
    }
    public void sortFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SortFragment())
                .addToBackStack(null)
                .commit();
    }

}


