//Assignment-HW02
//Sowmya deepthi Madineni
//UserRecyclerViewAdapter.java

package com.example.hw02;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class UserRecyclerViewAdapter extends RecyclerView.Adapter<UserRecyclerViewAdapter.UserViewHolder> {
    ArrayList<DataServices.User> users;

    public UserRecyclerViewAdapter(ArrayList<DataServices.User> user) {
        this.users=user;
    }

    public UserRecyclerViewAdapter(FragmentActivity activity, List<String> asList, SortFragment sortFragment) {
    }

    @NonNull
    @Override
    public UserRecyclerViewAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View convertView= LayoutInflater.from(parent.getContext()).inflate(R.layout.sortingitems,parent,false);
        UserViewHolder userViewHolder=new UserViewHolder(convertView);
        userViewHolder.textViewDetails = convertView.findViewById(R.id.textViewDetails);
        userViewHolder.ascendingImageView = convertView.findViewById(R.id.imageViewAscending);
        userViewHolder.descendingImageView = convertView.findViewById(R.id.imageViewDescending);
        return userViewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull UserRecyclerViewAdapter.UserViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 0;
    }
    public static class UserViewHolder extends RecyclerView.ViewHolder{

        TextView textViewDetails;
        ImageView ascendingImageView;
        ImageView descendingImageView;
        //public View ascendingImageView;
        //public View descendingImageView;
        //public View textViewDetails;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
