//Assignment-HW02
//Sowmya Deepthi Madineni
//UserAdapter.java

package com.example.hw02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends ArrayAdapter<DataServices.User> {

   public UserAdapter(@NonNull Context context, int adapter, @NonNull List<DataServices.User> objects) {
        super(context, 0, objects);
    }


    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null) {
            convertView = LayoutInflater.from(this.getContext()).inflate(R.layout.adapter, parent, false);
            ViewHolder viewholder = new ViewHolder();
            viewholder.userName = convertView.findViewById(R.id.name);
            viewholder.userAge = convertView.findViewById(R.id.age);
            viewholder.userState = convertView.findViewById(R.id.state);
            viewholder.userGroup = convertView.findViewById(R.id.group);
            viewholder.icon = convertView.findViewById(R.id.genderIcon);
            convertView.setTag(viewholder);
        }
        DataServices.User user=getItem(position);
        ViewHolder viewholder = (ViewHolder) convertView.getTag();
        viewholder.userName.setText(user.name);
        String finalresult = new Integer(user.age).toString();
        viewholder.userAge.setText(finalresult);
        viewholder.userState.setText(user.state);
        viewholder.userGroup.setText(user.group);
            if(user.gender.equals("Male")) {
                viewholder.icon.setImageResource(R.drawable.avatar_male);
            } else {
                viewholder.icon.setImageResource(R.drawable.avatar_female);
            }



        return convertView;
    }
private static class ViewHolder{
    TextView userName, userState, userGroup,userAge;
    ImageView icon;
}
}


