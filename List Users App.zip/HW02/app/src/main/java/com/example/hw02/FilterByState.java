//Assignment-HW02
//Sowmya deepthi Madineni
//FilterByState.java

package com.example.hw02;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FilterByState#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FilterByState extends Fragment {
    private static final String STATES_LIST = "STATES";
    private static final String USERS_LIST = "USERS";
    ListView States;
    ArrayAdapter stateAdapter;
    ArrayList<DataServices.User> userState=new ArrayList<>();
    public ArrayList<String> allStates;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    FilterstateInterface FilterstateInterface;

    public FilterByState(ArrayList<String> statesList,ArrayList<DataServices.User> userState) {
        this.allStates = statesList;
        this.userState=userState;
    }


    // TODO: Rename and change types and number of parameters
    public static FilterByState newInstance(ArrayList<String> ARG_PARAM1,ArrayList<DataServices.User> ARG_USERS) {
        FilterByState fragment = new FilterByState(ARG_PARAM1,ARG_USERS);
        Bundle args = new Bundle();
        args.putStringArrayList(STATES_LIST, ARG_PARAM1);
        args.putSerializable(USERS_LIST, ARG_USERS);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            allStates = getArguments().getStringArrayList(STATES_LIST);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_filter_by_state, container, false);
        States=view.findViewById(R.id.ListViewStates);
        stateAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1,allStates);
        States.setAdapter(stateAdapter);
        States.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                FilterstateInterface.positionClicked(position,userState);
                stateAdapter.notifyDataSetChanged();
            }
        });


        // Inflate the layout for this fragment
        return view;
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FilterByState.FilterstateInterface){
            FilterstateInterface = (FilterByState.FilterstateInterface)context;
        }else{
            throw new RuntimeException(context.toString()+"must implement IListener1");
        }
    }

    public interface FilterstateInterface {
        void positionClicked(int position,ArrayList<DataServices.User> users);
    }
}