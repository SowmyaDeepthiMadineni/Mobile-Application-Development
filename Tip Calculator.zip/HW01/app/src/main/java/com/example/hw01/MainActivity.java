//HomeWork01
//Sowmya Deepthi Madineni
//MainActivity.class


package com.example.hw01;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    EditText editbillTotal;
    TextView tipAmount,totalAmount,totalPerPerson,textViewProgress;
    RadioGroup radioGroupDiscount;
    RadioGroup radioGroupSplit;
    Button clearbutton;
    SeekBar seekBar;
    double tip,total,total_per_person;
    private Object watcher;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editbillTotal = findViewById(R.id.edittext_billtotal);
        radioGroupDiscount = findViewById(R.id.tip_percent_radiogroup);
        tipAmount = findViewById(R.id.tip_amount);
        totalAmount = findViewById(R.id.total_amount);
        radioGroupSplit = findViewById(R.id.splitby_radiogroup);
        totalPerPerson = findViewById(R.id.person_total);
        clearbutton = findViewById(R.id.clear_button);
        seekBar = findViewById(R.id.seekBar);
        textViewProgress = findViewById(R.id.textViewProgress);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                textViewProgress.setText(String.valueOf(progress));
                totalTip(radioGroupDiscount.getCheckedRadioButtonId());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        radioGroupDiscount.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checked_tip) {
                totalTip(checked_tip);

            }
        });
        radioGroupSplit.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checked) {
                if (checked == R.id.radiobutton_one) {
                    total_per_person = total;
                } else if (checked == R.id.radiobutton_two) {
                    total_per_person = total / 2;
                } else if (checked == R.id.radiobutton_three) {
                    total_per_person = total / 3;
                } else if (checked == R.id.radiobutton_four) {
                    total_per_person = total / 4;
                }
                totalPerPerson.setText(String.format("$%.1f", total_per_person));
            }
        });
        clearbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editbillTotal.setText("");
                radioGroupDiscount.check(R.id.radiobutton_10);
                seekBar.setProgress(seekBar.getProgress());
                tipAmount.setText("$0.0");
                totalAmount.setText("$0.0");
                radioGroupSplit.check(R.id.radiobutton_one);
                totalPerPerson.setText("");

            }
        });
    }
        private void totalTip(int checked_tip){
            float bill = Float.parseFloat(editbillTotal.getText().toString());
            if (checked_tip == R.id.radiobutton_10) {
                tip = bill * 0.10;
            } else if (checked_tip == R.id.radiobutton_15) {
                tip = bill * 0.15;
            } else if (checked_tip == R.id.radiobutton_18) {
                tip = bill * 0.18;
            } else if (checked_tip == R.id.radiobutton_custom) {
                float percent = seekBar.getProgress();
                tip = bill * (percent / 100);
            }
            tipAmount.setText(String.format("$%.1f", tip));
            total = bill + tip;
            totalAmount.setText(String.format("$%.1f", total));
        }
}




