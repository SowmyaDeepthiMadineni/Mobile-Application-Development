//InClass04
//Sowmya Deepthi Madineni

package com.example.inclass_04;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class LoginFragment extends Fragment {

    EditText Emailid, pwd;
    Button loginButton;
    TextView CreateNewAccount;
    LoginListener listener;
    public static final String LOGIN = "LOGIN";
    public static final String CREATENEWACCOUNT = "CREATENEWACCOUNT";

    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_login, container, false);
        Emailid = view.findViewById(R.id.editTextEmail);
        pwd = view.findViewById(R.id.editTextPassword);
        loginButton = view.findViewById(R.id.buttonLogin);
        CreateNewAccount = view.findViewById(R.id.textViewCreateNewAccount);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateId();
            }
        });

        CreateNewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.performLogin(" ", " ", CREATENEWACCOUNT);
            }
        });

        return view;
    }
    public void ValidateId() {

        String EmailId = Emailid.getText().toString();
       String password = pwd.getText().toString();

        if(EmailId.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(),"Enter Valid emailId and Password", Toast.LENGTH_LONG).show();
        }
        else {
            listener.performLogin(EmailId, password, LOGIN);
        }
    }
    public interface LoginListener {
        // interface for login

        void performLogin(String email, String passcode, String action);

    }
}