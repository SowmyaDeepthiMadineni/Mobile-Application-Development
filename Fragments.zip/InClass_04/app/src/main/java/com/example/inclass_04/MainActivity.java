//InClass04
//Sowmya Deepthi Madineni

package com.example.inclass_04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginListener{
    String id,password,action;
    private static String LOGIN_FRAGMENT = "LOGIN_FRAGMENT";
    private static String UPDATE_FRAGMENT = "UPDATE_FRAGMENT";
    private static String REGISTER_FRAGMENT = "REGISTER_FRAGMENT";
    private static String ACCOUNT_FRAGMENT = "ACCOUNT_FRAGMENT";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Login");
        getSupportFragmentManager().beginTransaction().
                add(R.id.ContainerView, new LoginFragment(), LOGIN_FRAGMENT).commit();
    }
    @Override
    public void performLogin(String Id, String pw, String action) {
        this.id = Id;
        this.password = pw;
        this.action = action;

        if (action.equals(LoginFragment.LOGIN)) {
            DataServices.AccountRequestTask account= DataServices.login(Id,pw);
            if (account != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.ContainerView,new AccountFragment() , ACCOUNT_FRAGMENT)
                        .commit();
                setTitle("Login");
            } else {
                Toast.makeText(MainActivity.this,"Enter Valid emailId and Password", Toast.LENGTH_LONG).show();
            }
        } else if (action.equals(LoginFragment.CREATENEWACCOUNT)) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.ContainerView, new RegistrationFragment(), REGISTER_FRAGMENT)
                    .commit();
            setTitle("Registration");
        }
    }
}