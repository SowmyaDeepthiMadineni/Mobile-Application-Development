//Inclass03
//StudentInformation Class
//Sowmya Deepthi Madineni



package com.example.inclass03;

import java.io.Serializable;

public class StudentInfo implements Serializable {
    String stuname,EmailId,StudentId,Dept;

    }

