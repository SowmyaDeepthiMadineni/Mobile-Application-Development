//InClass03
//SecondActivity.java
//Sowmya Deepthi Madineni

package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    Button Select,Cancel;
    RadioGroup radioGroup;
    public static String DEPT_VALUE="department";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setTitle("Department");
        Select =findViewById(R.id.buttonSelect);
        Cancel=findViewById(R.id.buttonCancel);
        radioGroup=findViewById(R.id.radioGroup);
        Select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int CheckedId=radioGroup.getCheckedRadioButtonId();
                if(CheckedId!=-1){
                    RadioButton CheckedButton=findViewById(CheckedId);
                    Intent intent=new Intent();
                    intent.putExtra(DEPT_VALUE,CheckedButton.getText().toString());
                    setResult(RESULT_OK,intent);
                    finish();
                }
                else{
                    Toast.makeText(SecondActivity.this,"No Department is selected,Please select any department", Toast.LENGTH_SHORT).show();
                    return;
                }
                
            }
        });
        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

    }
}