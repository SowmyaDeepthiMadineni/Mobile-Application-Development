//InClass03
//ThirdActivity.java
//Sowmya Deepthi Madineni

package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {
    TextView Name,Email,Id,Dept;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        setTitle("Profile");
        Name=findViewById(R.id.textViewName);
        Email=findViewById(R.id.textViewEmail);
        Id=findViewById(R.id.textViewId);
        Dept=findViewById(R.id.textViewDept);
        if(getIntent()!=null && getIntent().getExtras()!=null){
            StudentInfo student = (StudentInfo) getIntent().getSerializableExtra(MainActivity.PROFILE_ACTIVITY);
            Name.setText("Name:  "+student.stuname);
            Email.setText("Email:    "+student.EmailId);
            Id.setText("ID:        "+student.StudentId);
            Dept.setText("Dept:  "+student.Dept);
        }


    }
}