//InClass03
//MainActivity.java
//Sowmya Deepthi Madineni
package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static final String  PROFILE_ACTIVITY= "PROFILE_ACTIVITY";
    Button Select, Submit;
    TextView Department;
    EditText Name,emailid,studentid;
    final static public int REQ_CODE = 100;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String namePattern = "^[a-zA-Z\\s]*$";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Registration");
        Select = findViewById(R.id.button);
        Submit = findViewById(R.id.buttonsubmit);
        Department = findViewById(R.id.textViewDepartment);
        Name=findViewById(R.id.editTextPersonName);
        emailid=findViewById(R.id.editTextEmailId);
        studentid=findViewById(R.id.editTextNumberId);
        Select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivityForResult(intent,REQ_CODE);

            }
        });
        Submit.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = Name.getText().toString();
                String id = studentid.getText().toString();
                String email = emailid.getText().toString();
                String dept = Department.getText().toString();
                if (name.isEmpty()||(!name.matches(namePattern))) {
                    Toast.makeText(MainActivity.this,"Please enter valid name", Toast.LENGTH_SHORT).show();
                } else if (email.isEmpty() || (!email.matches(emailPattern))) {
                    Toast.makeText(MainActivity.this, "Please enter valid email", Toast.LENGTH_LONG).show();
                }
                else if(id.isEmpty()){
                    Toast.makeText(MainActivity.this,"Id Field is missing, please enter valid student id",Toast.LENGTH_LONG).show();
                }
                else if(dept.isEmpty()){
                    Toast.makeText(MainActivity.this,"Department Field is missing, please select valid department",Toast.LENGTH_LONG).show();
                }
                else {
                    StudentInfo st = new StudentInfo();
                    st.stuname = name;
                    st.EmailId = email;
                    st.StudentId = id;
                    st.Dept = dept;

                    Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
                    intent.putExtra("PROFILE_ACTIVITY", st);
                    startActivity(intent);
                }
            }
        }));

        }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (data != null && data.hasExtra(SecondActivity.DEPT_VALUE)) {
                String str = data.getStringExtra(SecondActivity.DEPT_VALUE);
                Department.setText(str);
            }
        }
    }
}