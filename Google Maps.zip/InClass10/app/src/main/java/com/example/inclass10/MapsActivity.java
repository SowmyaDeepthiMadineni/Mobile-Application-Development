package com.example.inclass10;

import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;

import android.os.Bundle;


import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.inclass10.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {


    ArrayList<TripDetails> tripdetails = null;
    private Marker MapStart,MapEnd;

    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        BufferedReader trip = null;

        try {
            trip = new BufferedReader(new InputStreamReader(getAssets().open("trip.json"), "UTF-8"));
            Gson gson = new Gson();
            TripDetails points = gson.fromJson(trip, TripDetails.class);
            tripdetails = points.gettripPoints();

        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        final ArrayList<LatLng> latLngValues = new ArrayList<>();
        for (TripDetails location : tripdetails) {
            LatLng value = new LatLng(Double.parseDouble(location.getLatitude()), Double.parseDouble(location.getLongitude()));
            latLngValues.add(value);
        }

        googleMap.addPolyline(new PolylineOptions()
                .addAll(latLngValues)
                .color(Color.BLUE));
        MapStart = googleMap.addMarker(new MarkerOptions().position(latLngValues.get(0)).title("Start Location"));
        MapStart.showInfoWindow();
        MapEnd = googleMap.addMarker(new MarkerOptions().position(latLngValues.get(latLngValues.size() - 1)).title("End Location"));
        MapEnd.showInfoWindow();

        googleMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for (int i = 0; i < latLngValues.size(); i++) {
                    builder.include(latLngValues.get(i));
                }
                LatLngBounds bounds = builder.build();
                CameraUpdate update = CameraUpdateFactory.newLatLngBounds(bounds, 50);
                googleMap.animateCamera(update);
            }
        });

    }
}