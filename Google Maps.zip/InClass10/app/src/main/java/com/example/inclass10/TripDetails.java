package com.example.inclass10;

import android.graphics.Point;

import java.util.ArrayList;

public class TripDetails {

    String latitude, longitude;

    ArrayList<TripDetails> points;
    public  ArrayList<TripDetails> gettripPoints() {

        return points;
    }

    @Override
    public String toString() {
        return "TripDetails{" +
                "latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                '}';
    }

    public TripDetails(String latitude,String longitude) {
        this.latitude = latitude;
        this.longitude=longitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}
