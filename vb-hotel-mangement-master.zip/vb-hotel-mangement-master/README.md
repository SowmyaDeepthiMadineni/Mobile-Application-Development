# VB Hotel Management Desktop Application

This project is aimed for developing a Hotel Management System. 
This will make hotels easier to handle the data such as check in and checkout times. 
This system can be access by employee of a hotel such as receptionist, and admin has an authority to access all the data such as employee data and also for the manipulation of data for example updating the records.

The software provides complete information of the booked and available room in the hotel. The prices and types of the rooms are also provided during the booking.

keep in mind this application was made for educational purpose, you can download use and edit as the way you want.
