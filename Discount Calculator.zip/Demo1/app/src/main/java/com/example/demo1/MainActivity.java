//Assignment-2
//Sowmya Deepthi Madineni
//InClass02--MainActivity.class

package com.example.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {
    EditText editTicketPrice;
    RadioGroup radioGroupDiscount;
    TextView textViewResult;
    Button buttonCalculate;
    Button Clearbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTicketPrice = findViewById(R.id.ticket_price);
        radioGroupDiscount = findViewById(R.id.discount_radio_group);
        textViewResult = findViewById(R.id.after_discount_price);
        Clearbutton = findViewById(R.id.clear_button);
        buttonCalculate = findViewById(R.id.calculate_button);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Double ticketPrice = Double.parseDouble(editTicketPrice.getText().toString());
                    double discounted_price = 0.0;
                    if (ticketPrice >= 0){
                        if(radioGroupDiscount.getCheckedRadioButtonId() == R.id.percent_5){
                            discounted_price = ticketPrice-ticketPrice * 0.05;
                        } else if(radioGroupDiscount.getCheckedRadioButtonId() == R.id.percent_10){
                            discounted_price = ticketPrice-ticketPrice * 0.10;
                        } else if(radioGroupDiscount.getCheckedRadioButtonId() == R.id.percent_15){
                            discounted_price = ticketPrice-ticketPrice * 0.15;
                        }else if(radioGroupDiscount.getCheckedRadioButtonId() == R.id.percent_20){
                            discounted_price = ticketPrice-ticketPrice * 0.20;
                        }else if(radioGroupDiscount.getCheckedRadioButtonId() == R.id.percent_50) {
                            discounted_price = ticketPrice-ticketPrice * 0.50;
                        }
                        textViewResult.setText(String.format("%.2f",discounted_price));
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Please enter a valid positive Integer", Toast.LENGTH_LONG).show();
                    }
                }
                catch (Exception ex){
                    Toast.makeText(MainActivity.this, "Please enter a valid positive Integer", Toast.LENGTH_LONG).show();
                    Log.d("exception",ex.toString());
                }
            }
        });
        Clearbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTicketPrice.setText("");
                radioGroupDiscount.check(R.id.percent_5);
                textViewResult.setText("");
            }
        });

    }
}